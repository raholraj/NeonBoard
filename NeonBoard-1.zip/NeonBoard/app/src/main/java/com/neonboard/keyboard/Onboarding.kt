package com.neonboard.keyboard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable

fun isImeEnabled(ctx: Context): Boolean {
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    return imm.enabledInputMethodList.any { it.packageName == ctx.packageName }
}

fun isImeSelected(ctx: Context): Boolean {
    val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
    return id.startsWith(ctx.packageName + "/")
}

class SplashActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Ui.BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(Ui.text(this, "NEON BOARD", 30f, Ui.ACCENT, true).apply {
            setShadowLayer(24f, 0f, 0f, Ui.ACCENT); typeface = Fonts.get(this@SplashActivity, 3)
        })
        col.addView(LottieAnimationView(this).apply {
            setAnimation(R.raw.loading); repeatCount = LottieDrawable.INFINITE; playAnimation()
        }, LinearLayout.LayoutParams(Ui.dp(this, 200), Ui.dp(this, 70)))
        root.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({
            val next = when {
                !Prefs.introDone -> IntroActivity::class.java
                !isImeEnabled(this) -> SetupActivity::class.java
                else -> MainActivity::class.java
            }
            startActivity(Intent(this, next)); finish()
        }, 1500)
    }
}

class IntroActivity : AppCompatActivity() {
    private val slides = listOf(
        "Neon & LED themes" to "12 glowing themes with LED-edge, electric and rolling-light effects.",
        "Make it yours" to "Custom colours, backgrounds with blur & dim, 10 fonts, sounds and key layout.",
        "Emoji art, clipboard & stickers" to "Emoji art packs, clipboard history, and your own stickers & GIFs."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        val pager = ViewPager2(this)
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = slides.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val c = p.context
                val col = LinearLayout(c).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    setPadding(Ui.dp(c, 28), 0, Ui.dp(c, 28), 0)
                    layoutParams = ViewGroup.LayoutParams(Ui.MATCH, Ui.MATCH)
                }
                col.addView(LottieAnimationView(c).apply {
                    setAnimation(R.raw.video_ff); repeatCount = LottieDrawable.INFINITE; playAnimation()
                }, LinearLayout.LayoutParams(Ui.dp(c, 180), Ui.dp(c, 72)))
                col.addView(Ui.text(c, "", 24f, Ui.ACCENT, true).apply { gravity = Gravity.CENTER; tag = "t"; setPadding(0, Ui.dp(c, 24), 0, Ui.dp(c, 10)) })
                col.addView(Ui.text(c, "", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER; tag = "d" })
                return object : RecyclerView.ViewHolder(col) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                h.itemView.findViewWithTag<TextView>("t").text = slides[i].first
                h.itemView.findViewWithTag<TextView>("d").text = slides[i].second
            }
        }
        val next = Ui.button(this, "Next") {}
        next.setOnClickListener {
            if (pager.currentItem < slides.size - 1) pager.currentItem += 1 else {
                Prefs.introDone = true
                startActivity(Intent(this, if (isImeEnabled(this)) MainActivity::class.java else SetupActivity::class.java))
                finish()
            }
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(p: Int) { next.text = if (p == slides.size - 1) "Get started" else "Next" }
        })
        root.addView(pager, Ui.lp(Ui.MATCH, 0, 1f))
        root.addView(next, Ui.lp(Ui.MATCH, Ui.WRAP).apply { setMargins(Ui.dp(this@IntroActivity, 24), 0, Ui.dp(this@IntroActivity, 24), Ui.dp(this@IntroActivity, 28)) })
        setContentView(root)
    }
}

class SetupActivity : AppCompatActivity() {
    private lateinit var s1: TextView
    private lateinit var s2: TextView
    private lateinit var go: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c = this
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(c, 24), Ui.dp(c, 48), Ui.dp(c, 24), Ui.dp(c, 24))
        }
        col.addView(Ui.text(c, "Set up Neon Board", 26f, Ui.ACCENT, true))
        col.addView(Ui.text(c, "Two quick steps to start typing in neon.", 14f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 24)) })
        s1 = Ui.text(c, "", 16f, Ui.TEXT, true)
        col.addView(s1)
        col.addView(Ui.button(c, "1 · Enable keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
            .apply { layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8); bottomMargin = Ui.dp(c, 20) } })
        s2 = Ui.text(c, "", 16f, Ui.TEXT, true)
        col.addView(s2)
        col.addView(Ui.button(c, "2 · Select Neon Board") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }.apply { layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8); bottomMargin = Ui.dp(c, 20) } })
        go = Ui.button(c, "Continue") { startActivity(Intent(c, MainActivity::class.java)); finish() }
        col.addView(go)
        col.addView(Ui.text(c, "Skip for now", 13f, Ui.MUTED).apply {
            gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 18), 0, 0)
            setOnClickListener { startActivity(Intent(c, MainActivity::class.java)); finish() }
        })
        setContentView(col)
    }

    private fun refresh() {
        val e = isImeEnabled(this); val s = isImeSelected(this)
        s1.text = (if (e) "✅ " else "⬜ ") + "Keyboard enabled"
        s2.text = (if (s) "✅ " else "⬜ ") + "Keyboard selected"
        go.alpha = if (e && s) 1f else 0.5f
    }

    override fun onResume() { super.onResume(); handler.post(poll) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(poll) }
}
