package com.neonboard.keyboard

import org.json.JSONObject

/** Tiny on-device word predictor: built-in common words + words you type (never leaves the phone). */
object Suggest {
    private val words = HashMap<String, Int>()
    @Volatile private var loaded = false
    private var dirty = 0

    private const val SEED =
        "the be to of and a in that have it for not on with he as you do at this but his by from they we say her she or an " +
        "will my one all would there their what so up out if about who get which go me when make can like time no just him " +
        "know take people into year your good some could them see other than then now look only come its over think also " +
        "back after use two how our work first well way even new want because any these give day most us is are was were " +
        "been has had did am hello hi thanks thank please sorry okay yes love friend home good morning night today tomorrow " +
        "happy birthday congratulations welcome where why again always never maybe really very much more please call message " +
        "meeting later soon tonight dinner lunch coffee phone number address email name help need still before little great"

    fun load() {
        if (loaded) return
        synchronized(words) {
            if (loaded) return
            for (w in SEED.split(" ")) if (w.length >= 2) words[w] = 1
            try {
                val js = Prefs.userWords
                if (js.isNotEmpty()) {
                    val o = JSONObject(js)
                    val it = o.keys()
                    while (it.hasNext()) { val k = it.next(); words[k] = o.optInt(k, 1) }
                }
            } catch (_: Exception) {}
            loaded = true
        }
    }

    fun isWordChar(ch: Char): Boolean =
        ch.isLetter() || ch == '\'' ||
            Character.getType(ch) == Character.NON_SPACING_MARK.toInt() ||
            Character.getType(ch) == Character.COMBINING_SPACING_MARK.toInt()

    fun trailingWord(before: CharSequence): String {
        var i = before.length
        while (i > 0 && isWordChar(before[i - 1])) i--
        return before.substring(i)
    }

    fun suggest(prefix: String, max: Int = 3): List<String> {
        if (prefix.isEmpty() || !loaded) return emptyList()
        val p = prefix.lowercase()
        val hits = synchronized(words) {
            words.entries.filter { it.key.startsWith(p) && it.key != p }
                .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key.length })
                .take(max).map { it.key }
        }
        return when {
            prefix.length > 1 && prefix.all { it.isUpperCase() } -> hits.map { it.uppercase() }
            prefix[0].isUpperCase() -> hits.map { it.replaceFirstChar { c -> c.uppercase() } }
            else -> hits
        }
    }

    fun learn(word: String) {
        val w = word.lowercase().trim('\'')
        if (w.length < 2 || w.length > 24 || !loaded) return
        var save: String? = null
        synchronized(words) {
            words[w] = (words[w] ?: 0) + 3
            if (words.size > 3000) {
                val drop = words.entries.sortedBy { it.value }.take(300).map { it.key }
                drop.forEach { words.remove(it) }
            }
            if (++dirty >= 15) {
                dirty = 0
                val o = JSONObject()
                for ((k, v) in words) if (v > 1) o.put(k, v)   // seed words stay at 1, not stored
                save = o.toString()
            }
        }
        save?.let { Prefs.userWords = it }
    }

    fun forget() {
        synchronized(words) {
            words.clear(); dirty = 0
            for (w in SEED.split(" ")) if (w.length >= 2) words[w] = 1
        }
        Prefs.userWords = ""
    }
}
