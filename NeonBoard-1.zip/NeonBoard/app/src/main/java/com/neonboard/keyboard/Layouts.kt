package com.neonboard.keyboard

enum class Kind { CHAR, SHIFT, DELETE, ENTER, SPACE, SYM, SYM2, ALPHA, LANG }

class KeyDef(
    val label: String,
    val kind: Kind = Kind.CHAR,
    val weight: Float = 1f,
    val alts: List<String> = emptyList()
)

class LangSpec(
    val id: String, val name: String, val rows: List<String>, val shiftRows: List<String>,
    val flag: String, val icon: String
)

object Layouts {
    private fun spec(id: String, name: String, rows: List<String>, flag: String, icon: String,
                      shift: List<String>? = null) =
        LangSpec(id, name, rows, shift ?: rows.map { it.uppercase() }, flag, icon)

    val langs = listOf(
        spec("en", "English", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "en", "english"),
        spec("hi", "हिन्दी", listOf("ौैाीूबहगदजड", "ोे्िुपरकतचट", "ंमनवलसय"), "hi", "hindi",
            listOf("औऐआईऊभङघधझढ", "ओएअइउफऱखथछठ", "ँणऩऴळशष")),
        spec("es", "Español", listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm"), "es", "spanish"),
        spec("fr", "Français", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"), "fr", "french"),
        spec("de", "Deutsch", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnm"), "de", "german"),
        spec("it", "Italiano", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "it", "italy"),
        spec("pt", "Português", listOf("qwertyuiop", "asdfghjklç", "zxcvbnm"), "pt", "portuguese"),
        spec("ru", "Русский", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"), "ru", "russian"),
        spec("af", "Afrikaans", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "af", "afrikaans"),
        spec("nl", "Nederlands", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "nl", "netherlands"),
        spec("sv", "Svenska", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"), "sv", "sv_sweden"),
        spec("nb", "Norsk", listOf("qwertyuiopå", "asdfghjkløæ", "zxcvbnm"), "nb", "norway"),
        spec("da", "Dansk", listOf("qwertyuiopå", "asdfghjklæø", "zxcvbnm"), "da", "danish"),
        spec("fi", "Suomi", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"), "fi", "finnish"),
        spec("is", "Íslenska", listOf("qwertyuiopð", "asdfghjklæö", "zxcvbnmþ"), "is", "icelandic"),
        spec("pl", "Polski", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "pl", "poland"),
        spec("cs", "Čeština", listOf("qwertzuiop", "asdfghjkl", "yxcvbnm"), "cs", "czech"),
        spec("sk", "Slovenčina", listOf("qwertzuiop", "asdfghjkl", "yxcvbnm"), "sk", "slovak"),
        spec("hu", "Magyar", listOf("qwertzuiop", "asdfghjkl", "yxcvbnm"), "hu", "hungary"),
        spec("ro", "Română", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "ro", "romanian"),
        spec("tr", "Türkçe", listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç"), "tr", "turkey",
            listOf("QWERTYUIOPĞÜ", "ASDFGHJKLŞİ", "ZXCVBNMÖÇ")),
        spec("tl", "Filipino", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "tl", "tagalog"),
        spec("id", "Indonesia", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "id", "indonesia"),
        spec("ms", "Melayu", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "ms", "malaysia"),
        spec("sw", "Kiswahili", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "sw", ""),
        spec("zu", "isiZulu", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "zu", "zulu"),
        spec("ca", "Català", listOf("qwertyuiop", "asdfghjkl", "zxcvbnmç"), "ca", "catalan"),
        spec("hr", "Hrvatski", listOf("qwertzuiopš", "asdfghjklčć", "yxcvbnmđž"), "hr", "croatia"),
        spec("sl", "Slovenščina", listOf("qwertzuiopš", "asdfghjklčž", "yxcvbnm"), "sl", "slovenian"),
        spec("et", "Eesti", listOf("qwertyuiopüõ", "asdfghjklöä", "zxcvbnm"), "et", "estonian"),
        spec("lv", "Latviešu", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "lv", "latvia"),
        spec("lt", "Lietuvių", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "lt", "lithuania"),
        spec("sq", "Shqip", listOf("qwertyuiopç", "asdfghjklë", "zxcvbnm"), "sq", ""),
        spec("uk", "Українська", listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбю"), "uk", "ukrainian"),
        spec("be", "Беларуская", listOf("йцукенгшўзх", "фывапролджэ", "ячсмітьбю"), "be", "belarusian"),
        spec("mk", "Македонски", listOf("љњертѕуиопшѓ", "асдфгхјклчќж", "зџцвбнм"), "mk", "macedonia"),
        spec("sr", "Српски", listOf("љњертзуиопшђж", "асдфгхјклчћ", "ѕџцвбнм"), "sr", "serbian"),
        spec("el", "Ελληνικά", listOf("ςερτυθιοπ", "ασδφγηξκλ", "ζχψωβνμ"), "el", "greek"),
        spec("he", "עברית", listOf("קראטוןםפ", "שדגכעיחלךף", "זסבהנמצתץ"), "he", "hebrew"),
        spec("ar", "العربية", listOf("ضصثقفغعهخحجد", "شسيبلاتنمكط", "ئءؤرىةوزظ"), "ar", "arabic"),
        spec("fa", "فارسی", listOf("ضصثقفغعهخحجچ", "شسیبلاتنمکگ", "ظطزرذدپو"), "fa", "persian"),
        spec("mr", "मराठी", listOf("ौैाीूबहगदजड", "ोे्िुपरकतचट", "ंमनवलसय"), "mr", "",
            listOf("औऐआईऊभङघधझढ", "ओएअइउफऱखथछठ", "ँणऩऴळशष")),
        spec("ne", "नेपाली", listOf("ौैाीूबहगदजड", "ोे्िुपरकतचट", "ंमनवलसय"), "ne", "nepal",
            listOf("औऐआईऊभङघधझढ", "ओएअइउफऱखथछठ", "ँणऩऴळशष")),
        spec("bn", "বাংলা", listOf("ৌৈাীূবহগদজড", "োে্িুপরকতচট", "ংমনলসয"), "bn", "bengali",
            listOf("ঔঐআঈঊভঙঘধঝঢ", "ওএঅইউফখথছঠ", "ঁণশষ")),
        spec("gu", "ગુજરાતી", listOf("ૌૈાીૂબહગદજડ", "ોે્િુપરકતચટ", "ંમનવલસય"), "gu", "",
            listOf("ઔઐઆઈઊભઙઘધઝઢ", "ઓએઅઇઉફખથછઠ", "ઁણળશષ")),
        spec("pa", "ਪੰਜਾਬੀ", listOf("ੌੈਾੀੂਬਹਗਦਜਡ", "ੋੇ੍ਿੁਪਰਕਤਚਟ", "ਂਮਨਵਲਸਯ"), "pa", "",
            listOf("ਔਐਆਈਊਭਙਘਧਝਢ", "ਓਏਅਇਉਫਖਥਛਠ", "ਁਣਲ਼ਸ਼")),
        spec("kn", "ಕನ್ನಡ", listOf("ೌೈಾೀೂಬಹಗದಜಡ", "ೋೇ್ಿುಪರಕತಚಟ", "ಂಮನವಲಸಯ"), "kn", "kannada",
            listOf("ಔಐಆಈಊಭಙಘಧಝಢ", "ಓಏಅಇಉಫಱಖಥಛಠ", "ಁಣಳಶಷ")),
        spec("te", "తెలుగు", listOf("ౌైాీూబహగదజడ", "ోే్ిుపరకతచట", "ంమనవలసయ"), "te", "",
            listOf("ఔఐఆఈఊభఙఘధఝఢ", "ఓఏఅఇఉఫఱఖథఛఠ", "ఁణఴళశష")),
        spec("ml", "മലയാളം", listOf("ൌൈാീൂബഹഗദജഡ", "ോേ്ിുപരകതചട", "ംമനവലസയ"), "ml", "",
            listOf("ഔഐആഈഊഭങഘധഝഢ", "ഓഏഅഇഉഫറഖഥഛഠ", "ഁണഩഴളശഷ")),
        spec("or", "ଓଡ଼ିଆ", listOf("ୌୈାୀୂବହଗଦଜଡ", "ୋେ୍ିୁପରକତଚଟ", "ଂମନଵଲସଯ"), "or", "",
            listOf("ଔଐଆଈଊଭଙଘଧଝଢ", "ଓଏଅଇଉଫଖଥଛଠ", "ଁଣଳଶଷ"))
    )

    fun lang(id: String) = langs.firstOrNull { it.id == id } ?: langs[0]

    private val accents = mapOf(
        'a' to "àáâäæãåāąăǎ", 'e' to "èéêëēėęěɛ", 'i' to "îïíīįìı", 'o' to "ôöòóœøōõőơ", 'u' to "ûüùúūůűųư",
        'c' to "çćč", 'n' to "ñńňņ", 's' to "śšßşșš", 'y' to "ÿý", 'z' to "žźż", 'l' to "łľĺļ", 'd' to "ðďđ",
        'g' to "ğģ", 'k' to "ķ", 'r' to "řŕ", 't' to "ťţț"
    )
    private val sym1 = listOf("1234567890", "@#$%&-+()/", "*\"':;!?")
    private val sym2 = listOf("~`|•√π÷×¶∆", "£€¥^°={}\\%", "©®™✓[]<>")

    private fun letterAlts(ch: Char, langId: String, shifted: Boolean, digit: String?): List<String> {
        val out = ArrayList<String>()
        digit?.let { out.add(it) }
        if (langId == "hi") return out
        accents[ch.lowercaseChar()]?.forEach { out.add(if (shifted) it.uppercaseChar().toString() else it.toString()) }
        return out
    }

    private fun letters(line: String, top: Boolean, langId: String, shifted: Boolean, numberRow: Boolean): List<KeyDef> =
        line.mapIndexed { i, ch ->
            val digit = if (top && !numberRow && i < 10) "1234567890"[i].toString() else null
            KeyDef(ch.toString(), alts = letterAlts(ch, langId, shifted, digit))
        }

    /** mode: 0 letters, 1 symbols, 2 more symbols. shifted: 0/1/2. */
    fun build(langId: String, mode: Int, shifted: Int, numberRow: Boolean, enterLabel: String, langName: String): List<List<KeyDef>> {
        val rows = ArrayList<List<KeyDef>>()
        if (mode == 0) {
            val spec = lang(langId)
            if (numberRow) rows.add("1234567890".map { KeyDef(it.toString()) })
            val src = if (shifted > 0) spec.shiftRows else spec.rows
            rows.add(letters(src[0], true, langId, shifted > 0, numberRow))
            rows.add(letters(src[1], false, langId, shifted > 0, numberRow))
            val r3 = ArrayList<KeyDef>()
            r3.add(KeyDef(if (shifted == 2) "⇪" else "⇧", Kind.SHIFT, 1.5f))
            r3.addAll(letters(src[2], false, langId, shifted > 0, numberRow))
            r3.add(KeyDef("⌫", Kind.DELETE, 1.5f))
            rows.add(r3)
        } else {
            val s = if (mode == 1) sym1 else sym2
            rows.add(s[0].map { KeyDef(it.toString()) })
            rows.add(s[1].map { KeyDef(it.toString()) })
            val r3 = ArrayList<KeyDef>()
            r3.add(KeyDef(if (mode == 1) "=\\<" else "1/2", Kind.SYM2, 1.5f))
            s[2].forEach { r3.add(KeyDef(it.toString())) }
            r3.add(KeyDef("⌫", Kind.DELETE, 1.5f))
            rows.add(r3)
        }
        rows.add(listOf(
            if (mode == 0) KeyDef("?123", Kind.SYM, 1.5f) else KeyDef("ABC", Kind.ALPHA, 1.5f),
            KeyDef("🌐", Kind.LANG, 1f),
            KeyDef(",", alts = listOf(";", ":", "\"", "'")),
            KeyDef(langName, Kind.SPACE, 4f),
            KeyDef(".", alts = listOf("!", "?", ":", ";", "-", "'", "\"", "@", "…")),
            KeyDef(enterLabel, Kind.ENTER, 1.5f)
        ))
        return rows
    }
}
