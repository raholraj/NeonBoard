package com.neonboard.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Haptics + synthesized key sounds (no audio asset files needed). */
object Feedback {
    private var vibrator: Vibrator? = null
    private val tracks = java.util.concurrent.ConcurrentHashMap<Int, AudioTrack>()
    private const val RATE = 22050

    private fun vib(ctx: Context): Vibrator? {
        if (vibrator == null) {
            vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }
        return vibrator
    }

    fun haptic(ctx: Context) {
        if (!Prefs.haptic) return
        val v = vib(ctx) ?: return
        val strength = Prefs.vibration.coerceIn(1, 100)
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val amp = (strength * 255 / 100).coerceIn(1, 255)
                v.vibrate(VibrationEffect.createOneShot(12, amp))
            } else {
                @Suppress("DEPRECATION") v.vibrate((strength / 4 + 5).toLong())
            }
        } catch (_: Exception) {}
    }

    private var appCtx: Context? = null
    private var pool: SoundPool? = null
    private val loaded: MutableSet<Int> = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
    private val poolIds = HashMap<Int, Int>()   // raw res id -> soundpool id

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    /** Selectable sounds: first 4 are synthesized, the rest are the bundled sound files. */
    val synthCount = 4
    val packs: List<Pair<String, Int>> = listOf(
        "Type 1" to R.raw.type1, "Type 2" to R.raw.type2, "Type 3" to R.raw.type3,
        "Press 1" to R.raw.press1, "Press 2" to R.raw.press2, "Press 3" to R.raw.press3,
        "Click A" to R.raw.click1, "Click B" to R.raw.click2, "Click C" to R.raw.click3,
        "Pop" to R.raw.pop, "Pop 2" to R.raw.pop2, "Break" to R.raw.break1, "Knock" to R.raw.knock,
        "Water" to R.raw.water1, "Dog" to R.raw.dog, "Shooting" to R.raw.shooting1,
        "Funny" to R.raw.funny1, "Funny Ah" to R.raw.reitanna_funnyah, "Funny Yay" to R.raw.reitanna_funnyyay,
        "Funny Yay 2" to R.raw.reitanna_funnyyay2, "Robot" to R.raw.littlerobotsoundfactory_mouth_06,
        "Poyo" to R.raw.taira_komori_poyo, "Fart" to R.raw.flash_shumway_fart_2
    )
    val styleNames: List<String> = listOf("Synth Click", "Synth Tick", "Synth Pop", "Synth Soft") + packs.map { it.first }

    @Synchronized
    private fun packId(resId: Int): Pair<SoundPool, Int>? {
        val ctx = appCtx ?: return null
        val sp = pool ?: SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build().also { p ->
            p.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
            pool = p
        }
        val sid = poolIds.getOrPut(resId) { sp.load(ctx, resId, 1) }
        return Pair(sp, sid)
    }

    private fun playPack(resId: Int, type: Int) {
        val (sp, sid) = packId(resId) ?: return
        if (!loaded.contains(sid)) return   // still loading: skip this one
        val v = (Prefs.volume / 100f).coerceIn(0.02f, 1f)
        val rate = when (type) { 1 -> 0.8f; 2 -> 0.9f; 3 -> 1.2f; else -> 1f }
        sp.play(sid, v, v, 1, 0, rate)
    }

    /** type: 0 normal, 1 space, 2 delete, 3 enter */
    fun sound(type: Int) {
        if (!Prefs.sound) return
        try {
            val style = Prefs.soundStyle
            if (style >= synthCount) {
                packs.getOrNull(style - synthCount)?.let { playPack(it.second, type) }
                return
            }
            val id = style * 10 + type
            val t = tracks[id] ?: makeTrack(style, type).also { tracks[id] = it }
            t.setVolume((Prefs.volume / 100f).coerceIn(0.02f, 1f))
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (_: Exception) {}
    }

    /** Pre-load the selected sound on a worker thread so the first key press is instant. */
    fun warm() {
        if (!Prefs.sound) return
        Thread {
            try {
                val style = Prefs.soundStyle
                if (style >= synthCount) {
                    packs.getOrNull(style - synthCount)?.let { packId(it.second) }
                } else {
                    for (type in 0..3) {
                        val id = style * 10 + type
                        if (!tracks.containsKey(id)) tracks[id] = makeTrack(style, type)
                    }
                }
            } catch (_: Exception) {}
        }.start()
    }

    fun release() {
        tracks.values.forEach { try { it.release() } catch (_: Exception) {} }
        tracks.clear()
        synchronized(this) { pool?.release(); pool = null; loaded.clear(); poolIds.clear() }
    }

    private fun makeTrack(style: Int, type: Int): AudioTrack {
        val pitch = when (type) { 1 -> 0.7f; 2 -> 0.85f; 3 -> 1.3f; else -> 1f }
        val dur = when (style) { 0 -> 0.035f; 1 -> 0.02f; 2 -> 0.06f; else -> 0.05f }
        val n = (RATE * dur).toInt()
        val pcm = ShortArray(n)
        val rnd = Random(7)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val env = exp(-t * (6f / dur)).toFloat()
            val s = when (style) {
                0 -> (0.6 * sin(2 * PI * 1800 * pitch * t) + 0.4 * (rnd.nextFloat() * 2 - 1)) // click
                1 -> sin(2 * PI * 3200 * pitch * t)                                          // tick
                2 -> sin(2 * PI * (700 - 4000 * t) * pitch * t)                              // pop
                else -> sin(2 * PI * 900 * pitch * t)                                        // soft
            }
            pcm[i] = (s * env * 28000).toInt().coerceIn(-32767, 32767).toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(n * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, n)
        return track
    }
}
