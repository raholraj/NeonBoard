package com.neonboard.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import androidx.core.graphics.ColorUtils
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

interface PanelHost {
    fun commit(text: String)
    fun backspace()
    fun closePanel()
    fun commitSticker(f: File)
    fun openApp()
}

private val mainHandler = Handler(Looper.getMainLooper())
private val pool = Executors.newFixedThreadPool(2)

private fun panelFrame(ctx: Context, title: String, host: PanelHost, content: View, withDelete: Boolean = true): LinearLayout {
    val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val bar = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8), 0)
    }
    bar.addView(Ui.button(ctx, "ABC") { host.closePanel() }.apply { setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 6), Ui.dp(ctx, 14), Ui.dp(ctx, 6)) })
    bar.addView(Ui.text(ctx, title, 14f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }, Ui.lp(0, Ui.WRAP, 1f))
    if (withDelete) bar.addView(Ui.button(ctx, "⌫") { host.backspace() }.apply { setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 6), Ui.dp(ctx, 14), Ui.dp(ctx, 6)) })
    root.addView(bar, Ui.lp(Ui.MATCH, Ui.dp(ctx, 40)))
    root.addView(content, Ui.lp(Ui.MATCH, 0, 1f))
    return root
}

// ---------------------------------------------------------------- emoji

object EmojiData {
    class Cat(val tag: String, val items: List<String>)
    private var cats: List<Cat>? = null

    @Synchronized
    fun load(ctx: Context): List<Cat> {
        cats?.let { return it }
        val out = ArrayList<Cat>()
        try {
            val s = ctx.assets.open("advance_emoji.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val l = o.getJSONArray("list")
                val items = ArrayList<String>()
                for (j in 0 until l.length()) items.add(l.getJSONObject(j).getString("word"))
                out.add(Cat(o.getString("tag"), items))
            }
        } catch (_: Exception) {}
        cats = out
        return out
    }

    val standard: List<String> by lazy {
        val l = ArrayList<String>()
        for (cp in 0x1F600..0x1F64F) l.add(String(Character.toChars(cp)))
        val extra = "👍👎👏🙌🙏💪👋🤝❤🔥✨🎉💯✅❌⭐🌹🎂🍕☕🚀🌈💔💕😍"
        var i = 0
        while (i < extra.length) {
            val cp = extra.codePointAt(i); l.add(String(Character.toChars(cp))); i += Character.charCount(cp)
        }
        l
    }

    fun iconFor(tag: String): Int = when (tag.lowercase()) {
        "fun" -> R.drawable.ic_fun
        "greetings" -> R.drawable.ic_greeting
        "love" -> R.drawable.ic_love
        "food" -> R.drawable.ic_food
        "lifestyle" -> R.drawable.ic_life_style
        else -> R.drawable.ic_season
    }
}

private class TextAdapter(
    var items: List<String>, val grid: Boolean, val onClick: (String) -> Unit, val onLong: ((String) -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
        val c = p.context
        val tv = TextView(c).apply {
            setTextColor(Ui.TEXT)
            if (grid) {
                textSize = 26f; gravity = Gravity.CENTER
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 46))
            } else {
                textSize = 15f; maxLines = 8; ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8))
                background = Ui.bg(0x33FFFFFF, 10f, ctx = c)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(Ui.dp(c, 8), Ui.dp(c, 3), Ui.dp(c, 8), Ui.dp(c, 3)) }
            }
        }
        return object : RecyclerView.ViewHolder(tv) {}
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
        val s = items[pos]
        (h.itemView as TextView).text = s
        h.itemView.setOnClickListener { onClick(s) }
        h.itemView.setOnLongClickListener { onLong?.invoke(s); onLong != null }
    }

    override fun getItemCount() = items.size
}

class EmojiPanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val list = RecyclerView(ctx)
    private val tabs = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private var selected = 0
    private val cats = EmojiData.load(ctx)

    init {
        orientation = VERTICAL
        val scroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(tabs) }
        val box = LinearLayout(ctx).apply { orientation = VERTICAL }
        box.addView(scroll, Ui.lp(Ui.MATCH, Ui.dp(ctx, 44)))
        box.addView(list, Ui.lp(Ui.MATCH, 0, 1f))
        addView(panelFrame(ctx, "Emoji & Emoji Art", host, box), Ui.lp(Ui.MATCH, Ui.MATCH))
        buildTabs()
        show(if (Prefs.recentEmoji().isNotEmpty()) 1 else 0)
    }

    private fun buildTabs() {
        tabs.removeAllViews()
        val c = context
        val total = cats.size + 2
        for (i in 0 until total) {
            val v: View = when (i) {
                0 -> TextView(c).apply { text = "😀"; textSize = 20f; gravity = Gravity.CENTER }
                1 -> TextView(c).apply { text = "🕘"; textSize = 20f; gravity = Gravity.CENTER }
                else -> ImageView(c).apply { setImageResource(EmojiData.iconFor(cats[i - 2].tag)); setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6)) }
            }
            v.background = if (i == selected) Ui.bg(ColorUtils.setAlphaComponent(Ui.ACCENT, 0x55), 10f, Ui.ACCENT, 1f, c) else null
            v.layoutParams = LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 40)).apply { setMargins(Ui.dp(c, 3), 0, Ui.dp(c, 3), 0) }
            v.setOnClickListener { show(i) }
            tabs.addView(v)
        }
    }

    private fun show(i: Int) {
        selected = i
        buildTabs()
        val c = context
        if (i == 0) {
            list.layoutManager = GridLayoutManager(c, 7)
            list.adapter = TextAdapter(EmojiData.standard, true, { pick(it) })
        } else {
            val items = if (i == 1) Prefs.recentEmoji() else cats[i - 2].items
            list.layoutManager = LinearLayoutManager(c)
            list.adapter = TextAdapter(items, false, { pick(it) })
        }
    }

    private fun pick(s: String) {
        host.commit(s)
        Prefs.addRecentEmoji(s)
    }
}

// ---------------------------------------------------------------- clipboard

class ClipboardPanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val list = RecyclerView(ctx).apply { layoutManager = LinearLayoutManager(ctx) }
    private val empty = Ui.text(ctx, "Copy some text and it will appear here.\nTap to paste · long-press to delete", 13f, Ui.MUTED).apply { gravity = Gravity.CENTER }
    private val holder = FrameLayout(ctx)

    init {
        orientation = VERTICAL
        holder.addView(list, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        holder.addView(empty, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        val frame = panelFrame(ctx, "Clipboard", host, holder)
        // add a "clear all" button next to the title
        val bar = frame.getChildAt(0) as LinearLayout
        bar.addView(Ui.button(ctx, "Clear") { Prefs.clearClips(); refresh() }.apply {
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 6), Ui.dp(ctx, 12), Ui.dp(ctx, 6))
        }, 2)
        addView(frame, Ui.lp(Ui.MATCH, Ui.MATCH))
        refresh()
    }

    private fun refresh() {
        val items = Prefs.clips()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = TextAdapter(items, false, { host.commit(it) }, { Prefs.removeClip(it); refresh() })
    }
}

// ---------------------------------------------------------------- quick menu

class MenuPanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        val col = LinearLayout(ctx).apply {
            orientation = VERTICAL
            setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 4), Ui.dp(ctx, 14), Ui.dp(ctx, 10))
        }
        col.addView(Ui.switchRow(ctx, "Key sound", Prefs.sound) { Prefs.sound = it })
        col.addView(Ui.switchRow(ctx, "Vibration", Prefs.haptic) { Prefs.haptic = it })
        col.addView(Ui.switchRow(ctx, "Number row", Prefs.numberRow) { Prefs.numberRow = it })
        col.addView(Ui.switchRow(ctx, "Key preview popup", Prefs.popup) { Prefs.popup = it })
        col.addView(Ui.seek(ctx, "Key height", 60, 140, Prefs.keyHeight, "%") { Prefs.keyHeight = it })
        col.addView(Ui.text(ctx, "Quick themes", 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 4)) })
        col.addView(Ui.chips(ctx, Themes.all.map { it.name }, Prefs.themeId) {
            Prefs.themeId = it; Prefs.customGlow = 0; Prefs.customKey = 0; Prefs.customText = 0
        })
        col.addView(Ui.button(ctx, "Open full settings") { host.openApp() }.apply {
            layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(ctx, 12) }
        })
        val sv = ScrollView(ctx).apply { addView(col) }
        addView(panelFrame(ctx, "Quick settings", host, sv, withDelete = false), Ui.lp(Ui.MATCH, Ui.MATCH))
    }
}

// ---------------------------------------------------------------- stickers / GIFs

object StickerStore {
    fun dir(ctx: Context): File = File(ctx.filesDir, "stickers").apply { mkdirs() }
    fun files(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray()).filter { it.isFile }.sortedByDescending { it.lastModified() }

    fun import(ctx: Context, uri: android.net.Uri): Boolean {
        return try {
            val mime = ctx.contentResolver.getType(uri) ?: ""
            val ext = when {
                mime.contains("gif") -> "gif"
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                else -> "jpg"
            }
            val f = File(dir(ctx), "s_${System.currentTimeMillis()}_${(0..9999).random()}.$ext")
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            f.exists() && f.length() > 0
        } catch (e: Exception) { false }
    }

    fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "gif" -> "image/gif"; "png" -> "image/png"; "webp" -> "image/webp"; else -> "image/jpeg"
    }

    fun thumb(f: File, size: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }
}

class StickerAdapter(val files: List<File>, val size: Int, val onClick: (File) -> Unit, val onLong: ((File) -> Unit)? = null) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val cache = android.util.LruCache<String, Bitmap>(40)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
        val iv = ImageView(p.context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, size)
            setPadding(Ui.dp(p.context, 3), Ui.dp(p.context, 3), Ui.dp(p.context, 3), Ui.dp(p.context, 3))
            background = Ui.bg(0x22FFFFFF, 8f, ctx = p.context)
        }
        return object : RecyclerView.ViewHolder(iv) {}
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
        val f = files[pos]
        val iv = h.itemView as ImageView
        iv.tag = f.path
        val hit = cache.get(f.path)
        if (hit != null) iv.setImageBitmap(hit) else {
            iv.setImageDrawable(null)
            pool.execute {
                val b = StickerStore.thumb(f, size)
                if (b != null) {
                    cache.put(f.path, b)
                    mainHandler.post { if (iv.tag == f.path) iv.setImageBitmap(b) }
                }
            }
        }
        iv.setOnClickListener { onClick(f) }
        iv.setOnLongClickListener { onLong?.invoke(f); onLong != null }
    }

    override fun getItemCount() = files.size
}

class StickerPanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val holder = FrameLayout(ctx)

    init {
        orientation = VERTICAL
        val loading = LottieAnimationView(ctx).apply {
            setAnimation(R.raw.loading); repeatCount = LottieDrawable.INFINITE; playAnimation()
        }
        holder.addView(loading, FrameLayout.LayoutParams(Ui.dp(ctx, 150), Ui.dp(ctx, 60), Gravity.CENTER))
        val frame = panelFrame(ctx, "Stickers & GIFs", host, holder)
        val bar = frame.getChildAt(0) as LinearLayout
        bar.addView(Ui.button(ctx, "＋") { host.openApp() }.apply {
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 6), Ui.dp(ctx, 12), Ui.dp(ctx, 6))
        }, 2)
        addView(frame, Ui.lp(Ui.MATCH, Ui.MATCH))
        pool.execute {
            val files = StickerStore.files(ctx)
            mainHandler.post { showFiles(files) }
        }
    }

    private fun showFiles(files: List<File>) {
        holder.removeAllViews()
        val c = context
        if (files.isEmpty()) {
            holder.addView(Ui.text(c, "No stickers yet.\nTap ＋ to add images or GIFs in the app.", 13f, Ui.MUTED).apply { gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            return
        }
        val rv = RecyclerView(c).apply {
            layoutManager = GridLayoutManager(c, 4)
            adapter = StickerAdapter(files, Ui.dp(c, 80), { host.commitSticker(it) })
        }
        holder.addView(rv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }
}

// ---------------------------------------------------------------- kaomoji

object KaomojiData {
    class Cat(val name: String, val items: List<String>)
    private var cats: List<Cat>? = null

    private fun readArray(ctx: Context, file: String): JSONArray =
        try {
            JSONArray(ctx.assets.open("kaomoji/$file").bufferedReader(Charsets.UTF_8).use { it.readText() })
        } catch (_: Exception) { JSONArray() }

    @Synchronized
    fun load(ctx: Context): List<Cat> {
        cats?.let { return it }
        // kaomoji_filter.json: [0] = unsupported characters, [1] = whole entries to hide
        val badChars = HashSet<Int>()
        val badWords = HashSet<String>()
        try {
            val f = readArray(ctx, "kaomoji_filter.json")
            if (f.length() > 0) {
                val a = f.getJSONArray(0)
                for (i in 0 until a.length()) a.getString(i).let { s ->
                    var k = 0
                    while (k < s.length) { val cp = s.codePointAt(k); badChars.add(cp); k += Character.charCount(cp) }
                }
            }
            if (f.length() > 1) {
                val b = f.getJSONArray(1)
                for (i in 0 until b.length()) badWords.add(b.getString(i))
            }
        } catch (_: Exception) {}

        fun ok(s: String): Boolean {
            if (badWords.contains(s)) return false
            var k = 0
            while (k < s.length) {
                val cp = s.codePointAt(k)
                if (badChars.contains(cp)) return false
                k += Character.charCount(cp)
            }
            return true
        }

        val out = ArrayList<Cat>()
        val main = readArray(ctx, "kaomoji.json")
        for (i in 0 until main.length()) {
            val o = main.getJSONObject(i)
            val arr = o.getJSONArray("emoji")
            val items = ArrayList<String>()
            for (j in 0 until arr.length()) arr.getString(j).let { if (ok(it)) items.add(it) }
            if (items.isNotEmpty()) out.add(Cat(o.getString("name").replaceFirstChar { it.uppercase() }, items))
        }
        val game = readArray(ctx, "game_kb_kaomoji.json")
        val gi = ArrayList<String>()
        for (j in 0 until game.length()) game.getString(j).let { if (ok(it)) gi.add(it) }
        if (gi.isNotEmpty()) out.add(Cat("Game", gi))
        cats = out
        return out
    }
}

class KaomojiPanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val list = RecyclerView(ctx).apply { layoutManager = GridLayoutManager(ctx, 2) }

    init {
        orientation = VERTICAL
        val cats = KaomojiData.load(ctx)
        val box = LinearLayout(ctx).apply { orientation = VERTICAL }
        fun show(i: Int) {
            list.adapter = TextAdapter(cats.getOrNull(i)?.items ?: emptyList(), false, { host.commit(it) })
        }
        if (cats.isEmpty()) {
            box.addView(Ui.text(ctx, "No kaomoji found", 13f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        } else {
            box.addView(Ui.chips(ctx, cats.map { it.name }, 0) { show(it) }.apply {
                setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 4), Ui.dp(ctx, 8), Ui.dp(ctx, 4))
            }, Ui.lp(Ui.MATCH, Ui.dp(ctx, 44)))
            box.addView(list, Ui.lp(Ui.MATCH, 0, 1f))
            show(0)
        }
        addView(panelFrame(ctx, "Kaomoji ツ", host, box), Ui.lp(Ui.MATCH, Ui.MATCH))
    }
}

// ---------------------------------------------------------------- fancy text style

class StylePanel(ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val list = RecyclerView(ctx).apply { layoutManager = GridLayoutManager(ctx, 2) }

    init {
        orientation = VERTICAL
        val box = LinearLayout(ctx).apply { orientation = VERTICAL }
        box.addView(Ui.text(ctx, "Styled letters work in every app. Tap a style, then type.", 12f, Ui.MUTED).apply {
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 2), Ui.dp(ctx, 12), Ui.dp(ctx, 4))
        })
        box.addView(list, Ui.lp(Ui.MATCH, 0, 1f))
        addView(panelFrame(ctx, "Text style", host, box, withDelete = false), Ui.lp(Ui.MATCH, Ui.MATCH))
        refresh()
    }

    private fun items(): List<String> = TextStyles.all.mapIndexed { i, st ->
        (if (i == Prefs.textStyle) "✓ " else "") + st.name + "\n" + TextStyles.apply(i, "Hello World 123")
    }

    private fun refresh() {
        list.adapter = TextAdapter(items(), false, { sel ->
            val idx = items().indexOf(sel)
            if (idx >= 0) { Prefs.textStyle = idx; refresh() }
        })
    }
}
