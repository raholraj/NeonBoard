package com.neonboard.keyboard

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.ColorUtils
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

/** Small helpers so the whole UI can be built in code (no XML layouts to maintain). */
object Ui {
    val BG = 0xFF0B0B14.toInt()
    val CARD = 0xFF16162A.toInt()
    /** Follows the active keyboard theme / custom glow colour. */
    val ACCENT: Int get() = Style.resolve().glow
    val MUTED = 0xFF9A9AB5.toInt()
    val TEXT = Color.WHITE

    fun dp(ctx: Context, v: Number): Int = (v.toFloat() * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun bg(color: Int, radius: Float, strokeColor: Int = 0, strokeDp: Float = 0f, ctx: Context? = null): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        val den = ctx?.resources?.displayMetrics?.density ?: android.content.res.Resources.getSystem().displayMetrics.density
        d.cornerRadius = radius * den
        if (strokeDp > 0f) d.setStroke((strokeDp * den).toInt().coerceAtLeast(1), strokeColor)
        return d
    }

    fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun text(ctx: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun title(ctx: Context, s: String) = text(ctx, s, 16f, ACCENT, true).apply {
        setPadding(0, dp(ctx, 14), 0, dp(ctx, 6))
    }

    fun card(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
        background = bg(CARD, 14f, ColorUtils.setAlphaComponent(ACCENT, 90), 1.2f, ctx)
        layoutParams = lp(MATCH, WRAP).apply { bottomMargin = dp(ctx, 10) }
    }

    fun button(ctx: Context, label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label; textSize = 14f; setTextColor(ACCENT); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 16), dp(ctx, 10))
        background = bg(ColorUtils.setAlphaComponent(ACCENT, 0x22), 12f, ACCENT, 1.2f, ctx)
        setOnClickListener { onClick() }
    }

    fun chip(ctx: Context, label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (selected) Color.BLACK else TEXT)
        setPadding(dp(ctx, 12), dp(ctx, 7), dp(ctx, 12), dp(ctx, 7))
        background = if (selected) bg(ACCENT, 20f, ctx = ctx) else bg(0xFF22223A.toInt(), 20f, ctx = ctx)
        setOnClickListener { onClick() }
    }

    /** Row of single-select chips. */
    fun chips(ctx: Context, labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val sv = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun fill(sel: Int) {
            row.removeAllViews()
            labels.forEachIndexed { i, l ->
                val c = chip(ctx, l, i == sel) { fill(i); onPick(i) }
                c.layoutParams = lp(WRAP, WRAP).apply { rightMargin = dp(ctx, 8) }
                row.addView(c)
            }
        }
        fill(selected)
        sv.addView(row)
        return sv
    }

    fun switchRow(ctx: Context, title: String, checked: Boolean, onChange: (Boolean) -> Unit): SwitchCompat =
        SwitchCompat(ctx).apply {
            text = title; setTextColor(TEXT); textSize = 14f; isChecked = checked
            setPadding(0, dp(ctx, 6), 0, dp(ctx, 6))
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }

    fun seek(ctx: Context, title: String, min: Int, max: Int, value: Int, unit: String = "", onChange: (Int) -> Unit): View {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val label = text(ctx, "$title: $value$unit", 13f, MUTED)
        val sb = SeekBar(ctx).apply {
            this.max = max - min
            progress = value.coerceIn(min, max) - min
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$title: ${p + min}$unit"
                    if (fromUser) onChange(p + min)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(label); box.addView(sb)
        return box
    }

    /** Swatch row + (optional) callback. Colors are opaque ARGB. */
    val SWATCHES = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFFF2D95.toInt(), 0xFF9DFF00.toInt(), 0xFFB04DFF.toInt(), 0xFFFF7A1A.toInt(),
        0xFF4DA6FF.toInt(), 0xFFFF2020.toInt(), 0xFFFFD21A.toInt(), 0xFF1AFFC8.toInt(), 0xFFFF00E5.toInt(),
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF0B0B14.toInt(), 0xFF1A0033.toInt(), 0xFF001F3F.toInt()
    )

    fun swatches(ctx: Context, current: Int, onPick: (Int) -> Unit): View {
        val sv = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun fill(sel: Int) {
            row.removeAllViews()
            for (c in SWATCHES) {
                val v = View(ctx)
                val selected = (c == sel)
                v.background = bg(c, 20f, if (selected) Color.WHITE else 0x55FFFFFF, if (selected) 3f else 1f, ctx)
                v.layoutParams = lp(dp(ctx, 36), dp(ctx, 36)).apply { rightMargin = dp(ctx, 8); topMargin = dp(ctx, 4); bottomMargin = dp(ctx, 4) }
                v.setOnClickListener { fill(c); onPick(c) }
                row.addView(v)
            }
        }
        fill(current)
        sv.addView(row)
        return sv
    }

    fun hueSlider(ctx: Context, onPick: (Int) -> Unit): View = seek(ctx, "Custom hue", 0, 360, 180, "°") { h ->
        onPick(Color.HSVToColor(floatArrayOf(h.toFloat(), 0.85f, 1f)))
    }
}
