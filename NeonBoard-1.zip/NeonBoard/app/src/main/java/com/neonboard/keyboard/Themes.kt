package com.neonboard.keyboard

data class NeonTheme(
    val id: Int, val name: String, val tags: String,
    val key: Int, val glow: Int, val text: Int, val bg1: Int, val bg2: Int
)

object Themes {
    private fun c(v: Long) = v.toInt()

    val all: List<NeonTheme> = listOf(
        NeonTheme(0, "Cyber Cyan", "cyan blue cool", c(0xCC0A1A24), c(0xFF00E5FF), c(0xFFE0FFFF), c(0xFF020B14), c(0xFF06222E)),
        NeonTheme(1, "Hot Pink", "pink magenta love", c(0xCC240A1A), c(0xFFFF2D95), c(0xFFFFE0F0), c(0xFF14020B), c(0xFF2E0620)),
        NeonTheme(2, "Lime Pulse", "green lime", c(0xCC0F1F08), c(0xFF9DFF00), c(0xFFF2FFD6), c(0xFF060F02), c(0xFF142A06)),
        NeonTheme(3, "Violet Storm", "purple violet", c(0xCC160A28), c(0xFFB04DFF), c(0xFFF0E0FF), c(0xFF0A0214), c(0xFF220A3D)),
        NeonTheme(4, "Sunset Orange", "orange warm", c(0xCC241208), c(0xFFFF7A1A), c(0xFFFFEBD9), c(0xFF140802), c(0xFF35140A)),
        NeonTheme(5, "Ice Blue", "blue ice white", c(0xCC0A1424), c(0xFF4DA6FF), c(0xFFE6F2FF), c(0xFF020814), c(0xFF0A1E3D)),
        NeonTheme(6, "Crimson Red", "red blood", c(0xCC240808), c(0xFFFF2020), c(0xFFFFE0E0), c(0xFF140202), c(0xFF2E0606)),
        NeonTheme(7, "Gold Rush", "gold yellow", c(0xCC241F08), c(0xFFFFD21A), c(0xFFFFF6D1), c(0xFF141002), c(0xFF2E2406)),
        NeonTheme(8, "Aurora", "teal green aurora", c(0xCC08241F), c(0xFF1AFFC8), c(0xFFD9FFF5), c(0xFF02140F), c(0xFF063A2E)),
        NeonTheme(9, "Magenta Night", "magenta night", c(0xCC1A0A24), c(0xFFFF00E5), c(0xFFFFE0FB), c(0xFF0A0210), c(0xFF260633)),
        NeonTheme(10, "Mono White", "white mono minimal", c(0xCC181818), c(0xFFFFFFFF), c(0xFFFFFFFF), c(0xFF050505), c(0xFF1A1A1A)),
        NeonTheme(11, "Retro Wave", "retro synth pink cyan", c(0xCC1A0A30), c(0xFFFF4DDB), c(0xFFFFE6FA), c(0xFF0F0222), c(0xFF2A0A55))
    )

    fun byId(id: Int): NeonTheme = all.firstOrNull { it.id == id } ?: all[0]
    fun current(): NeonTheme = byId(Prefs.themeId)
}

/** Final resolved colours (theme + user customisation). */
class Style(val key: Int, val glow: Int, val text: Int, val bg1: Int, val bg2: Int) {
    companion object {
        fun resolve(): Style {
            val t = Themes.current()
            return Style(
                if (Prefs.customKey != 0) Prefs.customKey else t.key,
                if (Prefs.customGlow != 0) Prefs.customGlow else t.glow,
                if (Prefs.customText != 0) Prefs.customText else t.text,
                t.bg1, t.bg2
            )
        }
    }
}

object Fonts {
    /** All uploaded font files (assets/fonts). */
    val files = listOf(
        "Amaranth.ttf", "Anita_semi_square.ttf", "Arabella.ttf", "BebasNeue-Regular.otf", "Brawler.ttf",
        "C_BOX.TTF", "C_BOX_D.TTF", "Caviar_Dreams_Bold.ttf", "CaviarDreams_Italic.ttf", "CaviarDreams_BoldItalic.ttf",
        "CaviarDreams.ttf", "ChopinScript.ttf", "CoffeeTin_Initials.ttf", "DISTRO__.ttf", "DISTROL_.ttf", "DISTROM_.ttf",
        "DISTROB_.ttf", "DISTROH_.ttf", "DISTROBL.ttf", "DISTROBT.ttf",
        "LilitaOne.ttf", "LittleLordFontleroyNF.ttf", "LOKICOLA.TTF", "Poppins_Medium.ttf",
        "PrimerApples.TTF", "Rye-Regular.ttf", "SairaStencilOne-Regular.ttf", "SVN_Poky.ttf"
    )
    val names = listOf(
        "Amaranth", "Anita Semi Square", "Arabella", "Bebas Neue", "Brawler",
        "C Box", "C Box D", "Caviar Dreams Bold", "Caviar Dreams Italic", "Caviar Dreams Bold Italic",
        "Caviar Dreams", "Chopin Script", "CoffeeTin Initials", "Distro", "Distro Light", "Distro Mix",
        "Distro Bold", "Distro Heavy", "Distro Black", "Distro Bats (symbols)",
        "Lilita One", "Little Lord Fontleroy", "Loki Cola", "Poppins Medium",
        "Primer Apples", "Rye", "Saira Stencil One", "SVN Poky"
    )
    private val cache = HashMap<Int, android.graphics.Typeface>()

    fun get(ctx: android.content.Context, index: Int): android.graphics.Typeface {
        val i = index.coerceIn(0, files.size - 1)
        return cache.getOrPut(i) {
            try {
                android.graphics.Typeface.createFromAsset(ctx.applicationContext.assets, "fonts/" + files[i])
            } catch (e: Exception) {
                android.graphics.Typeface.DEFAULT_BOLD
            }
        }
    }
}

/** Language flags (assets/flags) and subtype icons (assets/lang_icons), decoded lazily and cached. */
object LangIcons {
    private val cache = HashMap<String, android.graphics.Bitmap?>()

    private fun load(ctx: android.content.Context, path: String): android.graphics.Bitmap? =
        cache.getOrPut(path) {
            try {
                ctx.applicationContext.assets.open(path).use { android.graphics.BitmapFactory.decodeStream(it) }
            } catch (e: Exception) { null }
        }

    fun flag(ctx: android.content.Context, langId: String): android.graphics.Bitmap? =
        load(ctx, "flags/" + Layouts.lang(langId).flag + ".webp")

    fun icon(ctx: android.content.Context, langId: String): android.graphics.Bitmap? =
        load(ctx, "lang_icons/" + Layouts.lang(langId).icon + ".webp")
}
