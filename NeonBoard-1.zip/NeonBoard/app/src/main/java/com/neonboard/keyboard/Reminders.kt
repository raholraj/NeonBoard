package com.neonboard.keyboard

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object Reminders {
    private const val DAY = 24L * 60 * 60 * 1000

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for ((i, days) in listOf(3, 10).withIndex()) {
            val pi = PendingIntent.getBroadcast(
                ctx, 100 + i, Intent(ctx, ReminderReceiver::class.java).putExtra("days", days),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
            val at = Prefs.installTime + days * DAY
            if (Prefs.reminders && at > System.currentTimeMillis()) am.set(AlarmManager.RTC, at, pi)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Prefs.init(ctx)
        if (!Prefs.reminders) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("remind", "Reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, "remind")
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Neon Board")
            .setContentText("Try a new neon theme or effect for your keyboard ✨")
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(7, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Prefs.init(ctx)
        Reminders.schedule(ctx)
    }
}
