package com.neonboard.keyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class NeonIME : InputMethodService(), NeonKeyboardView.Listener, PanelHost,
    SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var root: LinearLayout
    private lateinit var keyboard: NeonKeyboardView
    private lateinit var toolbar: LinearLayout
    private lateinit var panelHolder: FrameLayout
    private lateinit var bgView: View
    private val handler = Handler(Looper.getMainLooper())
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var panelOpen = false
    private var flagBtn: ImageView? = null
    private var styleBtn: TextView? = null
    private lateinit var topBar: FrameLayout
    private lateinit var suggestBar: LinearLayout
    private val suggestViews = ArrayList<TextView>()
    private var currentWord = ""
    private var noLearn = false

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Feedback.init(this)
        Prefs.register(this)
        Thread { Suggest.load(); EmojiData.load(this); KaomojiData.load(this) }.start()
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipListener = ClipboardManager.OnPrimaryClipChangedListener {
            try {
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
                if (!t.isNullOrBlank() && t.length < 5000) Prefs.addClip(t)
            } catch (_: Exception) {}
        }
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        Prefs.unregister(this)
        clipListener?.let { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(it) }
        Feedback.release()
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key != null && Prefs.SILENT_KEYS.contains(key)) return
        handler.removeCallbacks(refresh)
        handler.postDelayed(refresh, 60)
    }

    private val refresh = Runnable {
        if (::keyboard.isInitialized) {
            keyboard.reload()
            updateFlag()
            styleToolbar()
            resizePanel()
        }
    }

    override fun onCreateInputView(): View {
        keyboard = NeonKeyboardView(this).also { it.listener = this }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val items = listOf("😀" to { openPanel(0) }, "ツ" to { openPanel(4) }, "📋" to { openPanel(1) },
            "🖼" to { openPanel(2) }, "⚡" to { openPanel(3) })
        for ((label, action) in items) {
            toolbar.addView(TextView(this).apply {
                text = label; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Ui.TEXT)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1f))
        }
        val sb = TextView(this).apply {
            text = "𝓐"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Ui.TEXT)
            setOnClickListener { openPanel(5) }
        }
        styleBtn = sb
        toolbar.addView(sb, LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1f))
        val fb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(Ui.dp(this@NeonIME, 8), Ui.dp(this@NeonIME, 8), Ui.dp(this@NeonIME, 8), Ui.dp(this@NeonIME, 8))
            setOnClickListener { keyboard.cycleLanguage() }
        }
        flagBtn = fb
        toolbar.addView(fb, LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1f))
        updateFlag()
        updateStyleBtn()
        toolbar.addView(TextView(this).apply {
            text = "⚙"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Ui.TEXT)
            setOnClickListener { openApp() }
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1f))
        panelHolder = FrameLayout(this).apply { visibility = View.GONE }
        suggestBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        suggestViews.clear()
        for (i in 0 until 3) {
            val tv = TextView(this).apply {
                textSize = 16f; gravity = Gravity.CENTER; maxLines = 1; setTextColor(Ui.TEXT)
                setOnClickListener { pickSuggestion(text.toString()) }
            }
            suggestViews.add(tv)
            suggestBar.addView(tv, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))
        }
        topBar = FrameLayout(this)
        topBar.addView(toolbar, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        topBar.addView(suggestBar, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        root.addView(topBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 38)))
        root.addView(panelHolder, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(keyboard, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        styleToolbar()
        return root
    }

    private fun updateStyleBtn() {
        styleBtn?.setTextColor(if (Prefs.textStyle != 0) Style.resolve().glow else Ui.TEXT)
    }

    private fun updateFlag() {
        val b = flagBtn ?: return
        b.setImageBitmap(LangIcons.flag(this, keyboard.currentLang()))
    }

    override fun onLanguageChanged(id: String) { updateFlag(); updateAutoCap() }

    private fun styleToolbar() {
        if (!::topBar.isInitialized) return
        val st = Style.resolve()
        topBar.setBackgroundColor(st.bg1)
        for (tv in suggestViews) tv.setTextColor(st.text)
    }

    // ---- word suggestions ----
    private fun updateSuggestions() {
        if (!::suggestBar.isInitialized) return
        val ic = currentInputConnection
        if (ic == null || noLearn || panelOpen || !Prefs.suggestions || Prefs.textStyle != 0) { currentWord = ""; showSuggestions(emptyList()); return }
        val before = ic.getTextBeforeCursor(32, 0)?.toString() ?: ""
        currentWord = Suggest.trailingWord(before)
        showSuggestions(if (currentWord.isEmpty()) emptyList() else Suggest.suggest(currentWord))
    }

    private fun showSuggestions(list: List<String>) {
        if (list.isEmpty()) {
            if (suggestBar.visibility != View.GONE) { suggestBar.visibility = View.GONE; toolbar.visibility = View.VISIBLE }
            return
        }
        for (i in suggestViews.indices) {
            val tv = suggestViews[i]
            tv.text = list.getOrNull(i) ?: ""
            tv.visibility = if (i < list.size) View.VISIBLE else View.INVISIBLE
        }
        toolbar.visibility = View.GONE
        suggestBar.visibility = View.VISIBLE
    }

    private fun pickSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        if (s.isEmpty()) return
        ic.beginBatchEdit()
        if (currentWord.isNotEmpty()) ic.deleteSurroundingText(currentWord.length, 0)
        ic.commitText("$s ", 1)
        ic.endBatchEdit()
        Suggest.learn(s)
        currentWord = ""
        showSuggestions(emptyList())
        updateAutoCap()
    }

    private fun learnCurrent() {
        if (!noLearn && Prefs.suggestions && Prefs.textStyle == 0 && currentWord.length >= 2) Suggest.learn(currentWord)
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        closePanel()
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        noLearn = cls != InputType.TYPE_CLASS_TEXT ||
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            (info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        Feedback.warm()
        keyboard.setMode(if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 1 else 0)
        keyboard.setEnterLabel(enterLabelFor(info))
        keyboard.setAnimating(true)
        updateAutoCap()
        updateSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        keyboard.setAnimating(false)
    }

    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, e: Int, f: Int) {
        super.onUpdateSelection(a, b, c, d, e, f)
        updateAutoCap()
        updateSuggestions()
    }

    private fun enterLabelFor(info: EditorInfo): String {
        if (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0) return "↵"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "↵"
        }
    }

    private fun updateAutoCap() {
        if (!::keyboard.isInitialized || !Prefs.autoCap || keyboard.currentLang() == "hi") return
        val ei = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        if (ei.inputType == InputType.TYPE_NULL) return
        keyboard.setAutoShift(ic.getCursorCapsMode(ei.inputType) != 0)
    }

    // ---- NeonKeyboardView.Listener ----
    override fun onText(text: String) {
        if (text.length == 1 && !Suggest.isWordChar(text[0])) learnCurrent()
        currentInputConnection?.commitText(TextStyles.apply(Prefs.textStyle, text), 1)
        updateAutoCap()
        updateSuggestions()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        learnCurrent()
        if (Prefs.doubleSpace) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                updateAutoCap(); updateSuggestions()
                return
            }
        }
        ic.commitText(" ", 1)
        updateAutoCap(); updateSuggestions()
    }

    override fun onDelete() { backspace() }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        learnCurrent()
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ---- PanelHost ----
    override fun commit(text: String) { currentInputConnection?.commitText(text, 1) }

    override fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateAutoCap()
        updateSuggestions()
    }

    override fun closePanel() {
        if (!::panelHolder.isInitialized) return
        panelOpen = false
        panelHolder.removeAllViews()
        panelHolder.visibility = View.GONE
        keyboard.visibility = View.VISIBLE
        updateStyleBtn()
        updateSuggestions()
    }

    private fun openPanel(kind: Int) {
        val v: View = when (kind) {
            0 -> EmojiPanel(this, this)
            1 -> ClipboardPanel(this, this)
            2 -> StickerPanel(this, this)
            4 -> KaomojiPanel(this, this)
            5 -> StylePanel(this, this)
            else -> MenuPanel(this, this)
        }
        panelHolder.removeAllViews()
        panelHolder.addView(v, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        panelOpen = true
        showSuggestions(emptyList())
        keyboard.visibility = View.GONE
        panelHolder.visibility = View.VISIBLE
        resizePanel()
    }

    private fun resizePanel() {
        if (!::panelHolder.isInitialized || !panelOpen) return
        val lp = panelHolder.layoutParams
        lp.height = keyboard.desiredHeight()
        panelHolder.layoutParams = lp
        panelHolder.setBackgroundColor(Style.resolve().bg1)
    }

    override fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    override fun commitSticker(f: File) {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection
        if (ei == null || ic == null) return
        val mime = StickerStore.mimeOf(f)
        val ok = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes(mime, it) }
        if (!ok) {
            Toast.makeText(this, "This app doesn't accept images from the keyboard", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", f)
        val info = InputContentInfoCompat(uri, ClipDescription(f.name, arrayOf(mime)), null)
        var flags = 0
        if (Build.VERSION.SDK_INT >= 25) flags = flags or InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
        InputConnectionCompat.commitContent(ic, ei, info, flags, null)
    }
}
