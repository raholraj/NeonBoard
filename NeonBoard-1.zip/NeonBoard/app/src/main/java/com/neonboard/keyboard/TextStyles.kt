package com.neonboard.keyboard

/**
 * Fancy text: converts typed A-Z / a-z / 0-9 into Unicode styled letters so the chosen look
 * travels with the message into ANY app (an IME cannot change the font of another app's text).
 */
object TextStyles {
    class TStyle(val name: String, val conv: (Char) -> String)

    private fun cp(c: Int) = String(Character.toChars(c))

    private fun math(name: String, upper: Int, lower: Int, digit: Int = -1, ex: Map<Char, Int> = emptyMap()) =
        TStyle(name) { ch ->
            when {
                ex.containsKey(ch) -> cp(ex.getValue(ch))
                ch in 'A'..'Z' -> cp(upper + (ch - 'A'))
                ch in 'a'..'z' -> cp(lower + (ch - 'a'))
                ch in '0'..'9' && digit >= 0 -> cp(digit + (ch - '0'))
                else -> ch.toString()
            }
        }

    private const val SMALL_CAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"

    val all: List<TStyle> = listOf(
        TStyle("Normal") { it.toString() },
        math("Bold", 0x1D400, 0x1D41A, 0x1D7CE),
        math("Italic", 0x1D434, 0x1D44E, -1, mapOf('h' to 0x210E)),
        math("Bold Italic", 0x1D468, 0x1D482),
        math("Script", 0x1D49C, 0x1D4B6, -1, mapOf(
            'B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110, 'L' to 0x2112,
            'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134)),
        math("Bold Script", 0x1D4D0, 0x1D4EA),
        math("Fraktur", 0x1D504, 0x1D51E, -1, mapOf('C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128)),
        math("Bold Fraktur", 0x1D56C, 0x1D586),
        math("Double-struck", 0x1D538, 0x1D552, 0x1D7D8, mapOf(
            'C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119, 'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124)),
        math("Sans", 0x1D5A0, 0x1D5BA, 0x1D7E2),
        math("Sans Bold", 0x1D5D4, 0x1D5EE, 0x1D7EC),
        math("Sans Italic", 0x1D608, 0x1D622),
        math("Sans Bold Italic", 0x1D63C, 0x1D656),
        math("Monospace", 0x1D670, 0x1D68A, 0x1D7F6),
        TStyle("Circled") { ch ->
            when {
                ch in 'A'..'Z' -> cp(0x24B6 + (ch - 'A'))
                ch in 'a'..'z' -> cp(0x24D0 + (ch - 'a'))
                ch in '1'..'9' -> cp(0x2460 + (ch - '1'))
                ch == '0' -> cp(0x24EA)
                else -> ch.toString()
            }
        },
        TStyle("Squared") { ch ->
            when {
                ch in 'A'..'Z' -> cp(0x1F130 + (ch - 'A'))
                ch in 'a'..'z' -> cp(0x1F130 + (ch - 'a'))
                else -> ch.toString()
            }
        },
        TStyle("Fullwidth") { ch ->
            when {
                ch in 'A'..'Z' -> cp(0xFF21 + (ch - 'A'))
                ch in 'a'..'z' -> cp(0xFF41 + (ch - 'a'))
                ch in '0'..'9' -> cp(0xFF10 + (ch - '0'))
                else -> ch.toString()
            }
        },
        TStyle("Small Caps") { ch ->
            when {
                ch in 'a'..'z' -> SMALL_CAPS[ch - 'a'].toString()
                ch in 'A'..'Z' -> SMALL_CAPS[ch - 'A'].toString()
                else -> ch.toString()
            }
        },
        TStyle("Strikethrough") { ch -> if (ch.isWhitespace()) ch.toString() else ch + "\u0336" },
        TStyle("Underline") { ch -> if (ch.isWhitespace()) ch.toString() else ch + "\u0332" }
    )

    val names: List<String> get() = all.map { it.name }

    fun apply(index: Int, text: String): String {
        if (index <= 0 || index >= all.size) return text
        val conv = all[index].conv
        val sb = StringBuilder(text.length * 2)
        for (ch in text) sb.append(conv(ch))
        return sb.toString()
    }
}
