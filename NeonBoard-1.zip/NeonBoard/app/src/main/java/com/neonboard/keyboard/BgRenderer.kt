package com.neonboard.keyboard

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

/** Builds the keyboard background bitmap (theme gradient / solid / gradient / image + blur + dim). */
object BgRenderer {
    private var cache: Bitmap? = null
    private var cacheKey = ""

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun keyFor(w: Int, h: Int) = listOf(w, h, Prefs.themeId, Prefs.bgType, Prefs.bgColor, Prefs.bgGradStart, Prefs.bgGradEnd,
        Prefs.bgGradOrientation, Prefs.bgImagePath, Prefs.bgFocus, Prefs.blur, Prefs.dim, Prefs.bgVersion).joinToString("|")

    /** Already-rendered bitmap for the current settings, or null. Never blocks. */
    @Synchronized
    fun peek(w: Int, h: Int): Bitmap? {
        val c = cache
        return if (c != null && !c.isRecycled && cacheKey == keyFor(w, h)) c else null
    }

    /** Heavy renders (image decode + blur) run off the UI thread so typing never stutters. */
    fun renderAsync(w: Int, h: Int, done: (Bitmap) -> Unit) {
        exec.execute {
            val b = try { render(w, h) } catch (e: Throwable) { null }
            if (b != null) main.post { done(b) }
        }
    }

    @Synchronized
    fun render(w: Int, h: Int): Bitmap {
        val key = keyFor(w, h)
        cache?.let { if (key == cacheKey && !it.isRecycled) return it }

        val bmp = Bitmap.createBitmap(max(w, 1), max(h, 1), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val t = Themes.current()
        when (Prefs.bgType) {
            1 -> c.drawColor(Prefs.bgColor)
            2 -> {
                val (x1, y1, x2, y2) = when (Prefs.bgGradOrientation) {
                    1 -> listOf(0f, 0f, w.toFloat(), 0f)
                    2 -> listOf(0f, 0f, w.toFloat(), h.toFloat())
                    else -> listOf(0f, 0f, 0f, h.toFloat())
                }
                p.shader = LinearGradient(x1, y1, x2, y2, Prefs.bgGradStart, Prefs.bgGradEnd, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            }
            3 -> if (!drawImage(c, w, h)) {
                p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), t.bg1, t.bg2, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            }
            else -> {
                p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), t.bg1, t.bg2, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            }
        }
        var out = bmp
        if (Prefs.bgType == 3 && Prefs.blur > 0) out = blur(bmp, Prefs.blur)
        if (Prefs.dim > 0) {
            val dc = Canvas(out)
            dc.drawColor(Color.argb((Prefs.dim * 255 / 100).coerceIn(0, 255), 0, 0, 0))
        }
        cache = out
        cacheKey = key
        return out
    }

    /** Fast blur: shrink then stretch back (cheap, mobile friendly). */
    private fun blur(src: Bitmap, level: Int): Bitmap {
        val f = 1f + level * 0.6f
        val sw = max(2, (src.width / f).toInt()); val sh = max(2, (src.height / f).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val big = Bitmap.createScaledBitmap(small, src.width, src.height, true)
        if (small !== big) small.recycle()
        return big
    }

    private fun drawImage(c: Canvas, w: Int, h: Int): Boolean {
        val path = Prefs.bgImagePath
        if (path.isEmpty() || !File(path).exists()) return false
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        if (opts.outWidth <= 0) return false
        var sample = 1
        while (opts.outWidth / (sample * 2) >= w && opts.outHeight / (sample * 2) >= h) sample *= 2
        val img = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return false
        // centre-crop to keyboard aspect with adjustable focus (pan)
        val scale = max(w.toFloat() / img.width, h.toFloat() / img.height)
        val sw = img.width * scale; val sh = img.height * scale
        val f = Prefs.bgFocus / 100f
        val dx = -(sw - w) * f; val dy = -(sh - h) * f
        c.drawBitmap(img, null, RectF(dx, dy, dx + sw, dy + sh), Paint(Paint.FILTER_BITMAP_FLAG))
        img.recycle()
        return true
    }

    @Synchronized
    fun invalidate() { cacheKey = ""; Prefs.bgVersion = Prefs.bgVersion + 1 }

    /** Copy a picked image into app storage, downscaled. */
    fun importImage(ctx: Context, uri: android.net.Uri, destName: String): File? {
        return try {
            val dest = File(ctx.filesDir, destName)
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / (sample * 2) >= 1280) sample *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return null
            dest.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp.recycle()
            dest
        } catch (e: Exception) { null }
    }
}
