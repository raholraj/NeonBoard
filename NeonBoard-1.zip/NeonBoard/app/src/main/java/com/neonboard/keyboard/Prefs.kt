package com.neonboard.keyboard

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Single settings store shared by the main app and the keyboard service (same process). */
object Prefs {
    private lateinit var sp: SharedPreferences

    // keys that change at runtime and must NOT trigger a keyboard rebuild
    val SILENT_KEYS = setOf("clip_history", "recent_emoji", "cur_lang", "user_words", "text_style")

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("neon_prefs", Context.MODE_PRIVATE)
        }
    }

    fun register(l: SharedPreferences.OnSharedPreferenceChangeListener) = sp.registerOnSharedPreferenceChangeListener(l)
    fun unregister(l: SharedPreferences.OnSharedPreferenceChangeListener) = sp.unregisterOnSharedPreferenceChangeListener(l)

    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun put(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    // ---- theme / colours ----
    var themeId: Int get() = int("theme_id", 0); set(v) = put("theme_id", v)
    var customGlow: Int get() = int("custom_glow", 0); set(v) = put("custom_glow", v)   // 0 = use theme
    var customKey: Int get() = int("custom_key", 0); set(v) = put("custom_key", v)
    var customText: Int get() = int("custom_text", 0); set(v) = put("custom_text", v)
    var favorites: Set<String>
        get() = sp.getStringSet("favorite_theme_ids", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("favorite_theme_ids", HashSet(v)).apply() }

    // ---- neon effect ----
    /** 0 none, 1 LED edge, 2 electric, 3 rolling light */
    var effect: Int get() = int("effect", 1); set(v) = put("effect", v)
    var effectSpeed: Int get() = int("effect_speed", 5); set(v) = put("effect_speed", v)   // 1..10
    var glowWidth: Int get() = int("glow_width", 5); set(v) = put("glow_width", v)         // 1..10

    // ---- background ----
    /** 0 theme gradient, 1 solid, 2 gradient, 3 image */
    var bgType: Int get() = int("bg_type", 0); set(v) = put("bg_type", v)
    var bgColor: Int get() = int("bg_color", 0xFF0B0B14.toInt()); set(v) = put("bg_color", v)
    var bgGradStart: Int get() = int("bg_grad_start", 0xFF1A0033.toInt()); set(v) = put("bg_grad_start", v)
    var bgGradEnd: Int get() = int("bg_grad_end", 0xFF001F3F.toInt()); set(v) = put("bg_grad_end", v)
    /** 0 vertical, 1 horizontal, 2 diagonal */
    var bgGradOrientation: Int get() = int("bg_grad_orient", 0); set(v) = put("bg_grad_orient", v)
    var bgImagePath: String get() = sp.getString("bg_image_path", "") ?: ""; set(v) = put("bg_image_path", v)
    var bgFocus: Int get() = int("bg_focus", 50); set(v) = put("bg_focus", v)               // 0..100 pan
    var blur: Int get() = int("blur_level", 0); set(v) = put("blur_level", v)               // 0..20
    var dim: Int get() = int("dim_background", 0); set(v) = put("dim_background", v)        // 0..80
    var bgVersion: Int get() = int("bg_version", 0); set(v) = put("bg_version", v)

    // ---- font ----
    var fontIndex: Int get() = int("font_index", 0); set(v) = put("font_index", v)

    // ---- layout ----
    var keyHeight: Int get() = int("key_height_factor", 100); set(v) = put("key_height_factor", v) // 60..140 %
    var hMargin: Int get() = int("key_horizontal_margin", 3); set(v) = put("key_horizontal_margin", v)
    var vMargin: Int get() = int("key_vertical_margin", 4); set(v) = put("key_vertical_margin", v)
    var bottomMargin: Int get() = int("keyboard_margin_bottom", 0); set(v) = put("keyboard_margin_bottom", v)
    var numberRow: Boolean get() = bool("enable_row_number", true); set(v) = put("enable_row_number", v)

    // ---- feedback ----
    var haptic: Boolean get() = bool("enable_haptic_feedback", true); set(v) = put("enable_haptic_feedback", v)
    var vibration: Int get() = int("custom_vibration_value", 50); set(v) = put("custom_vibration_value", v)
    var sound: Boolean get() = bool("config_custom_enable_sound", true); set(v) = put("config_custom_enable_sound", v)
    var volume: Int get() = int("custom_volume_value", 50); set(v) = put("custom_volume_value", v)
    var soundStyle: Int get() = int("sound_style", 0); set(v) = put("sound_style", v)       // 0..3
    var popup: Boolean get() = bool("show_key_press_popup", true); set(v) = put("show_key_press_popup", v)

    // ---- typing ----
    var autoCap: Boolean get() = bool("auto_cap", true); set(v) = put("auto_cap", v)
    var doubleSpace: Boolean get() = bool("double_space_period", true); set(v) = put("double_space_period", v)
    var enabledLangs: Set<String>
        get() = sp.getStringSet("enabled_langs", setOf("en", "hi")) ?: setOf("en")
        set(v) { sp.edit().putStringSet("enabled_langs", HashSet(if (v.isEmpty()) setOf("en") else v)).apply() }
    var suggestions: Boolean get() = bool("suggestions_on", true); set(v) = put("suggestions_on", v)
    var userWords: String get() = sp.getString("user_words", "") ?: ""; set(v) = put("user_words", v)
    var textStyle: Int get() = int("text_style", 0); set(v) = put("text_style", v)
    var curLang: String get() = sp.getString("cur_lang", "en") ?: "en"; set(v) = put("cur_lang", v)

    // ---- onboarding / reminders ----
    var introDone: Boolean get() = bool("intro_done", false); set(v) = put("intro_done", v)
    var reminders: Boolean get() = bool("reminders_on", true); set(v) = put("reminders_on", v)
    var installTime: Long
        get() = sp.getLong("install_time", 0L)
        set(v) { sp.edit().putLong("install_time", v).apply() }
    var askedNotif: Boolean get() = bool("asked_notif", false); set(v) = put("asked_notif", v)

    // ---- lists (JSON) ----
    private fun list(k: String): MutableList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp.getString(k, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {}
        return out
    }
    private fun saveList(k: String, l: List<String>) = put(k, JSONArray(l).toString())

    fun clips(): List<String> = list("clip_history")
    fun addClip(t: String) {
        if (t.isBlank()) return
        val l = list("clip_history"); l.remove(t); l.add(0, t)
        saveList("clip_history", l.take(30))
    }
    fun removeClip(t: String) { val l = list("clip_history"); l.remove(t); saveList("clip_history", l) }
    fun clearClips() = saveList("clip_history", emptyList())

    fun recentEmoji(): List<String> = list("recent_emoji")
    fun addRecentEmoji(t: String) {
        val l = list("recent_emoji"); l.remove(t); l.add(0, t)
        saveList("recent_emoji", l.take(24))
    }
}
