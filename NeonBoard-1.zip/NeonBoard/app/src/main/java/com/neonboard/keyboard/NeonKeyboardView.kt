package com.neonboard.keyboard

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Custom-drawn neon keyboard. Draws everything on one Canvas (fast, no per-key views),
 * with LED-edge / electric / rolling-light effects and long-press alternates.
 */
class NeonKeyboardView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onText(text: String)
        fun onSpace()
        fun onDelete()
        fun onEnter()
        fun onLanguageChanged(id: String) {}
    }

    var listener: Listener? = null

    private class KeyRect(val def: KeyDef, val cell: RectF, val rect: RectF, val path: Path, val perimeter: Float)

    private val handler = Handler(Looper.getMainLooper())
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var rows: List<List<KeyDef>> = emptyList()
    private val keys = ArrayList<KeyRect>()
    private var lang = "en"
    var mode = 0; private set
    var shifted = 0; private set
    var enterLabel = "↵"; private set
    private var style = Style.resolve()
    private var typeface: Typeface = Typeface.DEFAULT_BOLD
    private var bg: Bitmap? = null
    private var effect = 1
    // settings cached once per reload() so onDraw never touches SharedPreferences
    private var cGlowW = 5
    private var cSpeed = 5
    private var cPopup = true
    private var cNumberRow = true
    private var bgGen = 0
    private var bgLoading = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rollPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rollGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val sparkGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val sparkCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val sparkPath = Path()

    // touch state
    private var pressedKey: KeyRect? = null
    private var activePointer = -1
    private var popupAlts: List<String>? = null
    private var altLeft = 0f
    private var altTop = 0f
    private var altCell = 0f
    private var altSel = 0
    private var deleteFired = false
    private var lastShiftTap = 0L

    private val longPress = Runnable { startAlts() }
    private val deleteRepeat = object : Runnable {
        override fun run() {
            if (pressedKey?.def?.kind == Kind.DELETE) {
                listener?.onDelete()
                handler.postDelayed(this, 45)
            }
        }
    }

    // animation
    private var animating = false
    private val ticker = object : Runnable {
        override fun run() {
            if (!animating) return
            invalidate()
            handler.postDelayed(this, 45)
        }
    }

    init {
        Prefs.init(ctx)
        reload()
    }

    // ---------- public API ----------

    fun reload() {
        style = Style.resolve()
        typeface = Fonts.get(context, Prefs.fontIndex)
        effect = Prefs.effect
        cGlowW = Prefs.glowWidth; cSpeed = Prefs.effectSpeed; cPopup = Prefs.popup; cNumberRow = Prefs.numberRow
        bgGen++; bgLoading = false
        lang = Layouts.langs.firstOrNull { it.id == Prefs.curLang && Prefs.enabledLangs.contains(it.id) }?.id
            ?: enabledLangs().first().id
        bg = null
        rebuildLayout()
        requestLayout()
        animating = false
        handler.removeCallbacks(ticker)
        setAnimating(windowVisibility == VISIBLE)
    }

    fun desiredHeight(): Int {
        val rowCount = if (Prefs.numberRow) 5 else 4
        val rowH = dp(50f) * Prefs.keyHeight / 100f
        return (rowH * rowCount + dp(Prefs.bottomMargin.toFloat()) + dp(6f)).toInt()
    }

    fun setMode(m: Int) {
        mode = m
        if (m != 0) shifted = 0
        rebuildLayout()
    }

    fun setEnterLabel(l: String) {
        if (l != enterLabel) { enterLabel = l; rebuildLayout() }
    }

    /** Called by the IME for auto-capitalisation. */
    fun setAutoShift(on: Boolean) {
        if (shifted == 2 || mode != 0) return
        val ns = if (on) 1 else 0
        if (ns != shifted) { shifted = ns; rebuildLayout() }
    }

    fun currentLang(): String = lang

    fun cycleLanguage() {
        val list = enabledLangs()
        val i = list.indexOfFirst { it.id == lang }
        lang = list[(i + 1) % list.size].id
        Prefs.curLang = lang
        shifted = 0
        rebuildLayout()
        listener?.onLanguageChanged(lang)
    }

    fun setAnimating(on: Boolean) {
        val want = on && effect >= 2 && isAttachedToWindow
        if (want == animating) return
        animating = want
        handler.removeCallbacks(ticker)
        if (want) handler.post(ticker)
    }

    // ---------- layout ----------

    private fun enabledLangs(): List<LangSpec> {
        val en = Prefs.enabledLangs
        val l = Layouts.langs.filter { en.contains(it.id) }
        return if (l.isEmpty()) listOf(Layouts.langs[0]) else l
    }

    private fun rebuildLayout() {
        rows = Layouts.build(lang, mode, shifted, Prefs.numberRow, enterLabel, Layouts.lang(lang).name)
        layoutKeys()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), desiredHeight())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        bg = null; bgGen++; bgLoading = false
        layoutKeys()
    }

    private fun layoutKeys() {
        keys.clear()
        if (width == 0 || height == 0 || rows.isEmpty()) return
        val top = dp(3f)
        val bottom = dp(Prefs.bottomMargin.toFloat()) + dp(3f)
        val rowH = (height - top - bottom) / rows.size
        var maxW = 1f
        for (r in rows) maxW = max(maxW, r.sumOf { it.weight.toDouble() }.toFloat())
        val unit = width / maxW
        val hm = dp(Prefs.hMargin.coerceIn(0, 8).toFloat())
        val vm = dp(Prefs.vMargin.coerceIn(0, 8).toFloat())
        var y = top
        for (r in rows) {
            val rw = r.sumOf { it.weight.toDouble() }.toFloat() * unit
            var x = (width - rw) / 2f
            for (k in r) {
                val kw = k.weight * unit
                val cell = RectF(x, y, x + kw, y + rowH)
                val rect = RectF(x + hm, y + vm, x + kw - hm, y + rowH - vm)
                val rad = min(rect.height(), rect.width()) * 0.22f
                val path = Path().apply { addRoundRect(rect, rad, rad, Path.Direction.CW) }
                keys.add(KeyRect(k, cell, rect, path, PathMeasure(path, false).length))
                x += kw
            }
            y += rowH
        }
    }

    // ---------- drawing ----------

    override fun onDraw(c: Canvas) {
        val b = ensureBg()
        if (b != null) c.drawBitmap(b, 0f, 0f, null) else c.drawColor(style.bg1)

        val now = SystemClock.uptimeMillis()
        val glow = style.glow
        val gw = dp(0.7f + cGlowW * 0.17f)
        val rowH = if (rows.isEmpty()) 0f else (height - dp(6f)) / rows.size

        for (i in keys.indices) {
            val k = keys[i]
            val pressed = k === pressedKey
            val fn = k.def.kind != Kind.CHAR && k.def.kind != Kind.SPACE
            fill.color = when {
                pressed -> ColorUtils.blendARGB(style.key, glow, 0.45f)
                fn -> ColorUtils.blendARGB(style.key, glow, 0.14f)
                else -> style.key
            }
            c.drawPath(k.path, fill)
            when (effect) {
                0 -> { stroke.strokeWidth = dp(1f); stroke.color = ColorUtils.setAlphaComponent(glow, 120); c.drawPath(k.path, stroke) }
                1 -> led(c, k.path, gw, glow, pressed)
                2 -> { led(c, k.path, gw * 0.7f, glow, pressed); spark(c, k.rect, i, now, gw) }
                else -> { led(c, k.path, gw * 0.4f, glow, pressed, 0.35f); roll(c, k, now, gw, glow) }
            }
            drawLabel(c, k, rowH)
        }
        drawBubble(c)
        drawAlts(c)
    }

    /** Cheap backgrounds render inline; image backgrounds render on a worker thread. */
    private fun ensureBg(): Bitmap? {
        bg?.let { return it }
        BgRenderer.peek(width, height)?.let { bg = it; return it }
        if (Prefs.bgType == 3) {
            if (!bgLoading) {
                bgLoading = true
                val gen = bgGen
                BgRenderer.renderAsync(width, height) { bmp ->
                    if (gen == bgGen) { bg = bmp; bgLoading = false; invalidate() }
                }
            }
            return null
        }
        return BgRenderer.render(width, height).also { bg = it }
    }

    private fun led(c: Canvas, p: Path, gw: Float, glow: Int, pressed: Boolean, strength: Float = 1f) {
        val boost = if (pressed) 1.6f else 1f
        stroke.strokeWidth = gw * 4.2f
        stroke.color = ColorUtils.setAlphaComponent(glow, (34 * strength * boost).toInt().coerceAtMost(255))
        c.drawPath(p, stroke)
        stroke.strokeWidth = gw * 2.2f
        stroke.color = ColorUtils.setAlphaComponent(glow, (90 * strength * boost).toInt().coerceAtMost(255))
        c.drawPath(p, stroke)
        stroke.strokeWidth = gw
        stroke.color = ColorUtils.setAlphaComponent(glow, (255 * max(strength, 0.45f)).toInt())
        c.drawPath(p, stroke)
    }

    private fun spark(c: Canvas, r: RectF, idx: Int, now: Long, gw: Float) {
        val interval = (260 - cSpeed * 18).coerceAtLeast(60)
        val step = now / interval
        val rnd = Random(step * 31L + idx * 7919L)
        if (rnd.nextInt(3) != 0) return
        val top = rnd.nextBoolean()
        var x = r.left + rnd.nextFloat() * r.width()
        var y = if (top) r.top else r.bottom
        val dir = if (top) 1f else -1f
        sparkPath.reset()
        sparkPath.moveTo(x, y)
        for (s in 0 until 4) {
            x = (x + (rnd.nextFloat() - 0.5f) * dp(9f)).coerceIn(r.left, r.right)
            y += dir * r.height() * 0.2f * (0.6f + rnd.nextFloat())
            sparkPath.lineTo(x, y)
        }
        sparkGlow.strokeWidth = gw * 2.4f
        sparkGlow.color = ColorUtils.setAlphaComponent(style.glow, 110)
        c.drawPath(sparkPath, sparkGlow)
        sparkCore.strokeWidth = gw * 0.8f
        sparkCore.color = ColorUtils.blendARGB(style.glow, Color.WHITE, 0.75f)
        c.drawPath(sparkPath, sparkCore)
    }

    private fun roll(c: Canvas, k: KeyRect, now: Long, gw: Float, glow: Int) {
        val per = k.perimeter
        val seg = per * 0.28f
        val phase = (now * cSpeed * per / 6000f) % per
        val pe = DashPathEffect(floatArrayOf(seg, per - seg), phase)
        rollGlow.pathEffect = pe
        rollGlow.strokeWidth = gw * 4f
        rollGlow.color = ColorUtils.setAlphaComponent(glow, 80)
        c.drawPath(k.path, rollGlow)
        rollPaint.pathEffect = pe
        rollPaint.strokeWidth = gw * 1.6f
        rollPaint.color = ColorUtils.blendARGB(glow, Color.WHITE, 0.25f)
        c.drawPath(k.path, rollPaint)
    }

    private fun drawLabel(c: Canvas, k: KeyRect, rowH: Float) {
        val d = k.def
        val word = d.kind == Kind.ENTER || d.kind == Kind.SYM || d.kind == Kind.ALPHA || d.kind == Kind.SYM2 || d.kind == Kind.SPACE
        text.typeface = if (d.kind == Kind.CHAR) typeface else Typeface.DEFAULT_BOLD
        var size = rowH * (if (word) 0.27f else 0.4f)
        text.textSize = size
        val maxW = k.rect.width() * 0.88f
        val tw = text.measureText(d.label)
        if (tw > maxW) { size *= maxW / tw; text.textSize = size }
        text.color = when {
            d.kind == Kind.SHIFT && shifted > 0 -> style.glow
            d.kind == Kind.SPACE -> ColorUtils.setAlphaComponent(style.text, 150)
            else -> style.text
        }
        if (effect > 0 && d.kind == Kind.CHAR) text.setShadowLayer(dp(5f), 0f, 0f, style.glow) else text.clearShadowLayer()
        val fm = text.fontMetrics
        c.drawText(d.label, k.rect.centerX(), k.rect.centerY() - (fm.ascent + fm.descent) / 2f, text)

        if (d.kind == Kind.CHAR && !cNumberRow && mode == 0 && d.alts.isNotEmpty() && d.alts[0].length == 1 && d.alts[0][0].isDigit()) {
            hint.textSize = rowH * 0.2f
            hint.color = ColorUtils.setAlphaComponent(style.text, 130)
            c.drawText(d.alts[0], k.rect.right - dp(6f), k.rect.top + rowH * 0.24f, hint)
        }
    }

    private fun drawBubble(c: Canvas) {
        val k = pressedKey ?: return
        if (!cPopup || popupAlts != null || k.def.kind != Kind.CHAR) return
        val w = k.rect.width() * 1.35f
        val h = k.rect.height() * 1.2f
        val left = (k.rect.centerX() - w / 2).coerceIn(0f, max(0f, width - w))
        val top = max(0f, k.rect.top - h - dp(2f))
        val r = RectF(left, top, left + w, top + h)
        fill.color = ColorUtils.blendARGB(0xFF0B0B14.toInt(), style.glow, 0.22f)
        c.drawRoundRect(r, dp(10f), dp(10f), fill)
        stroke.strokeWidth = dp(1.5f); stroke.color = style.glow
        c.drawRoundRect(r, dp(10f), dp(10f), stroke)
        text.typeface = typeface; text.textSize = h * 0.5f; text.color = style.text
        text.setShadowLayer(dp(6f), 0f, 0f, style.glow)
        val fm = text.fontMetrics
        c.drawText(k.def.label, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, text)
    }

    private fun drawAlts(c: Canvas) {
        val a = popupAlts ?: return
        val h = pressedKey?.rect?.height() ?: return
        val r = RectF(altLeft, altTop, altLeft + altCell * a.size, altTop + h)
        fill.color = ColorUtils.blendARGB(0xFF0B0B14.toInt(), style.glow, 0.15f)
        c.drawRoundRect(r, dp(10f), dp(10f), fill)
        stroke.strokeWidth = dp(1.5f); stroke.color = style.glow
        c.drawRoundRect(r, dp(10f), dp(10f), stroke)
        for (i in a.indices) {
            val cell = RectF(altLeft + i * altCell, altTop, altLeft + (i + 1) * altCell, altTop + h)
            if (i == altSel) {
                fill.color = ColorUtils.setAlphaComponent(style.glow, 120)
                cell.inset(dp(3f), dp(3f))
                c.drawRoundRect(cell, dp(8f), dp(8f), fill)
            }
            text.typeface = typeface; text.textSize = h * 0.45f; text.color = style.text; text.clearShadowLayer()
            val fm = text.fontMetrics
            c.drawText(a[i], altLeft + (i + 0.5f) * altCell, altTop + h / 2f - (fm.ascent + fm.descent) / 2f, text)
        }
    }

    // ---------- touch ----------

    private fun keyAt(x: Float, y: Float): KeyRect? {
        for (k in keys) if (k.cell.contains(x, y)) return k
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { activePointer = e.getPointerId(0); down(e.x, e.y) }
            MotionEvent.ACTION_POINTER_DOWN -> {
                commitPressed()
                val i = e.actionIndex
                activePointer = e.getPointerId(i)
                down(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(activePointer)
                if (i >= 0) move(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP -> { up(); activePointer = -1 }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.getPointerId(e.actionIndex) == activePointer) { up(); activePointer = -1 }
            }
            MotionEvent.ACTION_CANCEL -> cancel()
        }
        return true
    }

    private fun feedback(k: KeyRect) {
        Feedback.haptic(context)
        Feedback.sound(when (k.def.kind) { Kind.SPACE -> 1; Kind.DELETE -> 2; Kind.ENTER -> 3; else -> 0 })
    }

    private fun down(x: Float, y: Float) {
        cancelTimers()
        val k = keyAt(x, y) ?: return
        pressedKey = k
        popupAlts = null
        deleteFired = false
        feedback(k)
        if (k.def.kind == Kind.DELETE) {
            listener?.onDelete(); deleteFired = true
            handler.postDelayed(deleteRepeat, 400)
        } else if (k.def.alts.isNotEmpty()) {
            handler.postDelayed(longPress, 380)
        }
        invalidate()
    }

    private fun move(x: Float, y: Float) {
        val a = popupAlts
        if (a != null) {
            altSel = ((x - altLeft) / altCell).toInt().coerceIn(0, a.size - 1)
            invalidate()
            return
        }
        val k = keyAt(x, y)
        if (k !== pressedKey) {
            cancelTimers()
            pressedKey = k
            if (k != null) {
                deleteFired = false
                Feedback.haptic(context)
                if (k.def.alts.isNotEmpty()) handler.postDelayed(longPress, 380)
            }
            invalidate()
        }
    }

    private fun up() {
        cancelTimers()
        val a = popupAlts
        if (a != null) {
            val t = a[altSel.coerceIn(0, a.size - 1)]
            popupAlts = null
            pressedKey = null
            listener?.onText(t)
            afterChar()
        } else {
            commitPressed()
        }
        invalidate()
    }

    private fun cancel() {
        cancelTimers()
        popupAlts = null
        pressedKey = null
        invalidate()
    }

    private fun cancelTimers() {
        handler.removeCallbacks(longPress)
        handler.removeCallbacks(deleteRepeat)
    }

    private fun startAlts() {
        val k = pressedKey ?: return
        if (k.def.alts.isEmpty()) return
        val alts = k.def.alts
        altCell = max(k.rect.width(), dp(38f))
        val total = altCell * alts.size
        altLeft = (k.rect.centerX() - total / 2f).coerceIn(0f, max(0f, width - total))
        altTop = max(0f, k.rect.top - k.rect.height() - dp(4f))
        altSel = ((k.rect.centerX() - altLeft) / altCell).toInt().coerceIn(0, alts.size - 1)
        popupAlts = alts
        Feedback.haptic(context)
        invalidate()
    }

    private fun commitPressed() {
        val k = pressedKey ?: return
        pressedKey = null
        cancelTimers()
        popupAlts = null
        val l = listener
        when (k.def.kind) {
            Kind.CHAR -> { l?.onText(k.def.label); afterChar() }
            Kind.SPACE -> l?.onSpace()
            Kind.DELETE -> if (!deleteFired) l?.onDelete()
            Kind.ENTER -> l?.onEnter()
            Kind.SHIFT -> toggleShift()
            Kind.SYM -> setMode(1)
            Kind.SYM2 -> setMode(if (mode == 1) 2 else 1)
            Kind.ALPHA -> setMode(0)
            Kind.LANG -> cycleLanguage()
        }
        invalidate()
    }

    private fun afterChar() {
        if (shifted == 1) { shifted = 0; rebuildLayout() }
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shifted = when {
            shifted == 2 -> 0
            now - lastShiftTap < 350 -> 2
            shifted == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        rebuildLayout()
    }

    // ---------- lifecycle ----------

    override fun onAttachedToWindow() { super.onAttachedToWindow(); setAnimating(true) }
    override fun onDetachedFromWindow() { setAnimating(false); cancelTimers(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); setAnimating(v == VISIBLE) }
}
