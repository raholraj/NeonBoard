# Neon Board – neon LED keyboard (Android, Kotlin)

Original implementation of the *features* in the "Neon LED Keyboard: Full Feature & Code Analysis" spec
(no code or assets copied from the third-party app). Uses your uploaded fonts, icons, Lottie files and `advance_emoji.json`.

## Build the APK
**Option A – GitHub Actions (phone friendly):** push this folder to a GitHub repo → Actions → *Build APK* →
download artifact `NeonBoard-debug-apk` → install.
**Option B – Android Studio:** open the folder, let it sync, Run (or Build > Build APK).
**Option C – CLI:** JDK 17 + Android SDK (platform 34), then `gradle :app:assembleDebug`.

After install: open the app → follow the setup wizard (enable + select keyboard).

## Where your assets are used
- `assets/fonts/*` – 28 keyboard fonts (Custom → Font)
- `assets/advance_emoji.json` + `res/drawable-nodpi/ic_*.png` – emoji-art panel and its category tabs
- `res/raw/loading.json` – splash + sticker panel loader · `res/raw/video_ff.json` – intro slides

## Not included (needs keys / servers / not sensible offline)
Giphy/Tenor/Unsplash online search, Play Billing, ads, Firebase, Play Asset Delivery theme packs,
gesture (swipe) typing, word suggestions/dictionaries. Stickers/GIFs come from your own gallery instead.

## Sounds
`res/raw/*` – 23 bundled key sounds (type, press, click, pop, break, knock, water, dog, shooting, funny…),
selectable in Custom → Sound & vibration (plus 4 synthesized styles). Credits (from your source.txt):
keyboard typing – freesfx.co.uk/sfx/type-keyboard · shooting – freesound.org/people/Pashee/sounds/415507 ·
knock – freesfx.co.uk/sfx/knock · dog – freesfx.co.uk/Category/Dogs/14. Others: see file names (reitanna, Taira Komori,
Little Robot Sound Factory, Flash Shumway). Check each sound's licence before publishing the app.

## Languages, flags, kaomoji
- `assets/lang_icons/*` (subtype icons) – shown next to each language in Settings; `assets/flags/*` – flag button in the keyboard toolbar (tap to switch language).
- 50 layouts (Latin, Cyrillic, Greek, Hebrew, Arabic, Persian, Devanagari + InScript-style Bengali/Gujarati/Punjabi/Kannada/Telugu/Malayalam/Odia). All 77 flags / 67 icons are bundled; a language without a layout yet (e.g. Thai, Korean, Japanese, Chinese, Tamil, Vietnamese) just isn't listed. Add a `spec(...)` in `Layouts.kt` and its flag/icon is picked up by name.
- `assets/kaomoji/*` – kaomoji panel (ツ button); `kaomoji_filter.json` hides entries with unsupported glyphs.

## Performance notes
- Keyboard is one custom-drawn View (no per-key views); effects animate at ~22 fps only while the keyboard is visible and stop when hidden.
- Settings are cached per reload (no SharedPreferences reads while drawing); image/blur backgrounds render on a worker thread; emoji/kaomoji/word data and the chosen key sound are pre-loaded in the background.
- Word suggestions: built-in common words + words you type (stored only on the phone, skipped in password/email/number fields).
