package com.neonboard.keyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** Mini theme preview card. */
class ThemeSwatchView(ctx: Context, private val t: NeonTheme) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, t.bg1, t.bg2, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        c.drawRoundRect(0f, 0f, w, h, 16f, 16f, p)
        p.shader = null
        val cols = 7; val rows = 3
        val kw = w / cols; val kh = h / (rows + 0.6f)
        for (r in 0 until rows) for (i in 0 until cols) {
            val rect = RectF(i * kw + kw * 0.14f, kh * 0.3f + r * kh + kh * 0.14f, (i + 1) * kw - kw * 0.14f, kh * 0.3f + (r + 1) * kh - kh * 0.14f)
            p.style = Paint.Style.FILL; p.color = t.key
            c.drawRoundRect(rect, 6f, 6f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 5f; p.color = ColorUtils.setAlphaComponent(t.glow, 60); c.drawRoundRect(rect, 6f, 6f, p)
            p.strokeWidth = 1.6f; p.color = t.glow; c.drawRoundRect(rect, 6f, 6f, p)
        }
    }
}

class MainActivity : AppCompatActivity() {
    lateinit var preview: NeonKeyboardView
    private lateinit var testField: EditText
    private lateinit var content: LinearLayout
    private lateinit var navRow: LinearLayout
    private var page = 0
    private var onBgPicked: (() -> Unit)? = null
    private var onStickersPicked: (() -> Unit)? = null

    private val pickBg = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val f = BgRenderer.importImage(this, uri, "bg_custom_${System.currentTimeMillis()}.jpg")
            if (f != null) {
                Prefs.bgImagePath = f.path; Prefs.bgType = 3; BgRenderer.invalidate(); preview.reload(); onBgPicked?.invoke()
            } else toast("Couldn't load that image")
        }
    }
    private val pickStickers = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        var n = 0
        uris.forEach { if (StickerStore.import(this, it)) n++ }
        if (uris.isNotEmpty()) toast("Added $n sticker(s)")
        onStickersPicked?.invoke()
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    fun pickBackground(done: () -> Unit) { onBgPicked = done; pickBg.launch("image/*") }
    fun pickStickerFiles(done: () -> Unit) { onStickersPicked = done; pickStickers.launch("image/*") }
    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var refreshPending = false
    private lateinit var titleView: TextView

    /** Coalesces rapid slider updates so dragging stays smooth. */
    fun refreshPreview() {
        if (refreshPending) return
        refreshPending = true
        uiHandler.postDelayed({
            refreshPending = false
            preview.reload()
            updateChrome()
        }, 40)
    }

    private fun updateChrome() {
        if (!::titleView.isInitialized) return
        val a = Ui.ACCENT
        titleView.setTextColor(a); titleView.setShadowLayer(14f, 0f, 0f, a)
        buildNav(page)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val c = this
        val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }

        titleView = Ui.text(c, "NEON BOARD", 18f, Ui.ACCENT, true).apply {
            setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 6)); setShadowLayer(14f, 0f, 0f, Ui.ACCENT)
            typeface = Fonts.get(c, 3)
        }
        root.addView(titleView)
        testField = EditText(c).apply {
            hint = "Tap keys below to test…"; setHintTextColor(Ui.MUTED); setTextColor(Ui.TEXT); textSize = 14f
            background = Ui.bg(Ui.CARD, 10f, ctx = c); setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8))
            showSoftInputOnFocus = false; maxLines = 2
        }
        root.addView(testField, Ui.lp(Ui.MATCH, Ui.WRAP).apply { setMargins(Ui.dp(c, 12), 0, Ui.dp(c, 12), Ui.dp(c, 6)) })

        preview = NeonKeyboardView(c)
        preview.listener = object : NeonKeyboardView.Listener {
            override fun onText(text: String) { testField.text.insert(testField.selectionStart.coerceAtLeast(0), text) }
            override fun onSpace() { onText(" ") }
            override fun onDelete() {
                val s = testField.selectionStart
                if (s > 0) testField.text.delete(s - 1, s)
            }
            override fun onEnter() { onText("\n") }
        }
        root.addView(preview, Ui.lp(Ui.MATCH, Ui.WRAP))

        val sv = ScrollView(c)
        content = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 12), Ui.dp(c, 12)) }
        sv.addView(content)
        root.addView(sv, Ui.lp(Ui.MATCH, 0, 1f))

        navRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Ui.CARD) }
        root.addView(navRow, Ui.lp(Ui.MATCH, Ui.dp(c, 54)))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 && !Prefs.askedNotif &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Prefs.askedNotif = true
            ActivityCompat.requestPermissions(c, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        showPage(0)
    }

    private fun showPage(i: Int) {
        page = i
        buildNav(i)
        content.removeAllViews()
        Pages(this, content).apply {
            when (i) { 0 -> themes(); 1 -> backdrop(); 2 -> custom(); 3 -> stickers(); else -> settings() }
        }
    }

    private fun buildNav(i: Int) {
        val c = this
        navRow.removeAllViews()
        listOf("🎨 Themes", "🖼 Backdrop", "✏ Custom", "😀 Stickers", "⚙ Settings").forEachIndexed { idx, l ->
            navRow.addView(TextView(c).apply {
                text = l; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(if (idx == i) Ui.ACCENT else Ui.MUTED)
                if (idx == i) typeface = Typeface.DEFAULT_BOLD
                setOnClickListener { showPage(idx) }
            }, Ui.lp(0, Ui.MATCH, 1f))
        }
    }

    override fun onResume() { super.onResume(); preview.reload() }
}

private class Pages(val a: MainActivity, val root: LinearLayout) {
    val c: Context = a

    // ---------------- themes ----------------
    fun themes() {
        root.addView(Ui.title(c, "Themes"))
        var query = ""
        var favOnly = false
        val grid = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        fun fill() {
            grid.removeAllViews()
            val favs = Prefs.favorites
            val list = Themes.all.filter {
                (query.isBlank() || (it.name + " " + it.tags).contains(query, true)) && (!favOnly || favs.contains(it.id.toString()))
            }
            if (list.isEmpty()) grid.addView(Ui.text(c, "No themes found", 13f, Ui.MUTED))
            list.chunked(2).forEach { pair ->
                val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEach { t ->
                    val card = LinearLayout(c).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8))
                        background = Ui.bg(Ui.CARD, 14f, if (Prefs.themeId == t.id) Ui.ACCENT else 0, 2f, c)
                    }
                    card.addView(ThemeSwatchView(c, t), Ui.lp(Ui.MATCH, Ui.dp(c, 84)))
                    val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    line.addView(Ui.text(c, t.name, 13f, Ui.TEXT, true), Ui.lp(0, Ui.WRAP, 1f))
                    line.addView(TextView(c).apply {
                        text = if (favs.contains(t.id.toString())) "❤" else "♡"; textSize = 20f; setTextColor(0xFFFF2D95.toInt())
                        setOnClickListener {
                            val s = Prefs.favorites.toMutableSet()
                            if (!s.remove(t.id.toString())) s.add(t.id.toString())
                            Prefs.favorites = s; fill()
                        }
                    })
                    card.addView(line)
                    card.setOnClickListener {
                        Prefs.themeId = t.id; Prefs.customGlow = 0; Prefs.customKey = 0; Prefs.customText = 0
                        a.refreshPreview(); fill()
                    }
                    row.addView(card, Ui.lp(0, Ui.WRAP, 1f).apply { setMargins(Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4)) })
                }
                if (pair.size == 1) row.addView(View(c), Ui.lp(0, 1, 1f))
                grid.addView(row)
            }
        }
        val search = EditText(c).apply {
            hint = "Search themes (e.g. pink, blue)"; setHintTextColor(Ui.MUTED); setTextColor(Ui.TEXT); textSize = 14f; maxLines = 1; isSingleLine = true
            background = Ui.bg(Ui.CARD, 10f, ctx = c); setPadding(Ui.dp(c, 12), Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; fill() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, co: Int, af: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, co: Int) {}
            })
        }
        root.addView(search, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(Ui.switchRow(c, "Favorites only", false) { favOnly = it; fill() })
        root.addView(grid)
        fill()
    }

    // ---------------- backdrop ----------------
    fun backdrop() {
        root.addView(Ui.title(c, "Background"))
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        fun build() {
            box.removeAllViews()
            val card = Ui.card(c)
            card.addView(Ui.chips(c, listOf("Theme", "Solid", "Gradient", "Image"), Prefs.bgType) { Prefs.bgType = it; a.refreshPreview(); build() })
            when (Prefs.bgType) {
                1 -> {
                    card.addView(Ui.text(c, "Colour", 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 10), 0, 0) })
                    card.addView(Ui.swatches(c, Prefs.bgColor) { Prefs.bgColor = it; a.refreshPreview() })
                    card.addView(Ui.hueSlider(c) { Prefs.bgColor = it; a.refreshPreview() })
                }
                2 -> {
                    card.addView(Ui.text(c, "Start colour", 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 10), 0, 0) })
                    card.addView(Ui.swatches(c, Prefs.bgGradStart) { Prefs.bgGradStart = it; a.refreshPreview() })
                    card.addView(Ui.text(c, "End colour", 13f, Ui.MUTED))
                    card.addView(Ui.swatches(c, Prefs.bgGradEnd) { Prefs.bgGradEnd = it; a.refreshPreview() })
                    card.addView(Ui.chips(c, listOf("Vertical", "Horizontal", "Diagonal"), Prefs.bgGradOrientation) { Prefs.bgGradOrientation = it; a.refreshPreview() })
                }
                3 -> {
                    card.addView(Ui.button(c, "Pick image from gallery") { a.pickBackground { build() } }.apply {
                        layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 10); bottomMargin = Ui.dp(c, 6) }
                    })
                    card.addView(Ui.seek(c, "Image position", 0, 100, Prefs.bgFocus, "%") { Prefs.bgFocus = it; a.refreshPreview() })
                    card.addView(Ui.seek(c, "Blur", 0, 20, Prefs.blur) { Prefs.blur = it; a.refreshPreview() })
                }
            }
            card.addView(Ui.seek(c, "Dim", 0, 80, Prefs.dim, "%") { Prefs.dim = it; a.refreshPreview() })
            box.addView(card)
        }
        build()
        root.addView(box)
    }

    // ---------------- custom ----------------
    fun custom() {
        root.addView(Ui.title(c, "Colours"))
        val colors = Ui.card(c)
        colors.addView(Ui.text(c, "Glow / neon colour", 13f, Ui.MUTED))
        colors.addView(Ui.swatches(c, Prefs.customGlow) { Prefs.customGlow = it; a.refreshPreview() })
        colors.addView(Ui.hueSlider(c) { Prefs.customGlow = it; a.refreshPreview() })
        colors.addView(Ui.text(c, "Key fill", 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(c, 8), 0, 0) })
        colors.addView(Ui.swatches(c, Prefs.customKey) { Prefs.customKey = ColorUtils.setAlphaComponent(it, 0xCC); a.refreshPreview() })
        colors.addView(Ui.text(c, "Text colour", 13f, Ui.MUTED))
        colors.addView(Ui.swatches(c, Prefs.customText) { Prefs.customText = it; a.refreshPreview() })
        colors.addView(Ui.button(c, "Reset to theme colours") { Prefs.customGlow = 0; Prefs.customKey = 0; Prefs.customText = 0; a.refreshPreview() }.apply {
            layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 10) }
        })
        root.addView(colors)

        root.addView(Ui.title(c, "Neon effect"))
        val fx = Ui.card(c)
        fx.addView(Ui.chips(c, listOf("None", "LED edge", "Electric", "Rolling"), Prefs.effect) { Prefs.effect = it; a.refreshPreview() })
        fx.addView(Ui.seek(c, "Glow width", 1, 10, Prefs.glowWidth) { Prefs.glowWidth = it; a.refreshPreview() })
        fx.addView(Ui.seek(c, "Animation speed", 1, 10, Prefs.effectSpeed) { Prefs.effectSpeed = it })
        root.addView(fx)

        root.addView(Ui.title(c, "Font"))
        val fonts = Ui.card(c)
        fun fillFonts() {
            fonts.removeAllViews()
            Fonts.names.forEachIndexed { i, n ->
                fonts.addView(TextView(c).apply {
                    text = "$n  —  Quick fox 123 नमस्ते"; textSize = 17f
                    typeface = Fonts.get(c, i)
                    setTextColor(if (Prefs.fontIndex == i) Ui.ACCENT else Ui.TEXT)
                    setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
                    setOnClickListener { Prefs.fontIndex = i; a.refreshPreview(); fillFonts() }
                })
            }
        }
        fillFonts()
        root.addView(fonts)

        root.addView(Ui.title(c, "Sound & vibration"))
        val snd = Ui.card(c)
        snd.addView(Ui.switchRow(c, "Key sound", Prefs.sound) { Prefs.sound = it })
        snd.addView(Ui.chips(c, Feedback.styleNames, Prefs.soundStyle) { Prefs.soundStyle = it; Feedback.sound(0); Feedback.sound(0) })
        snd.addView(Ui.seek(c, "Volume", 1, 100, Prefs.volume, "%") { Prefs.volume = it })
        snd.addView(Ui.button(c, "Test sound") { Feedback.sound(0) }.apply { layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8) } })
        snd.addView(Ui.switchRow(c, "Vibration", Prefs.haptic) { Prefs.haptic = it })
        snd.addView(Ui.seek(c, "Vibration strength", 1, 100, Prefs.vibration, "%") { Prefs.vibration = it; Feedback.haptic(c) })
        root.addView(snd)

        root.addView(Ui.title(c, "Keyboard layout"))
        val lay = Ui.card(c)
        lay.addView(Ui.switchRow(c, "Number row", Prefs.numberRow) { Prefs.numberRow = it; a.refreshPreview() })
        lay.addView(Ui.seek(c, "Key height", 60, 140, Prefs.keyHeight, "%") { Prefs.keyHeight = it; a.refreshPreview() })
        lay.addView(Ui.seek(c, "Horizontal gap", 0, 8, Prefs.hMargin, "dp") { Prefs.hMargin = it; a.refreshPreview() })
        lay.addView(Ui.seek(c, "Vertical gap", 0, 8, Prefs.vMargin, "dp") { Prefs.vMargin = it; a.refreshPreview() })
        lay.addView(Ui.seek(c, "Bottom margin", 0, 60, Prefs.bottomMargin, "dp") { Prefs.bottomMargin = it; a.refreshPreview() })
        root.addView(lay)
    }

    // ---------------- stickers ----------------
    fun stickers() {
        root.addView(Ui.title(c, "Stickers & GIFs"))
        root.addView(Ui.text(c, "Add your own images or GIFs. In the keyboard, tap 🖼 to send them (works in apps that accept images, like WhatsApp or Telegram). Long-press to delete.", 13f, Ui.MUTED))
        val holder = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        fun fill() {
            holder.removeAllViews()
            val files = StickerStore.files(c)
            if (files.isEmpty()) { holder.addView(Ui.text(c, "Nothing here yet.", 14f, Ui.TEXT).apply { setPadding(0, Ui.dp(c, 16), 0, 0) }); return }
            val rv = RecyclerView(c).apply {
                layoutManager = GridLayoutManager(c, 4)
                isNestedScrollingEnabled = false
                adapter = StickerAdapter(files, Ui.dp(c, 84), { a.toast(it.name) }, { f -> f.delete(); fill() })
            }
            holder.addView(rv, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        root.addView(Ui.button(c, "＋ Add images / GIFs") { a.pickStickerFiles { fill() } }.apply {
            layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 10) }
        })
        root.addView(holder)
        fill()
    }

    // ---------------- settings ----------------
    fun settings() {
        root.addView(Ui.title(c, "Typing"))
        val t = Ui.card(c)
        t.addView(Ui.switchRow(c, "Key preview popup", Prefs.popup) { Prefs.popup = it; a.refreshPreview() })
        t.addView(Ui.switchRow(c, "Auto-capitalise", Prefs.autoCap) { Prefs.autoCap = it })
        t.addView(Ui.switchRow(c, "Double space → period", Prefs.doubleSpace) { Prefs.doubleSpace = it })
        t.addView(Ui.switchRow(c, "Word suggestions (learns on your phone)", Prefs.suggestions) { Prefs.suggestions = it })
        t.addView(Ui.button(c, "Forget learned words") { Suggest.load(); Suggest.forget(); a.toast("Learned words cleared") }.apply {
            layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8) }
        })
        root.addView(t)

        root.addView(Ui.title(c, "Languages (🌐 key cycles)"))
        val l = Ui.card(c)
        Layouts.langs.forEach { lg ->
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(ImageView(c).apply {
                setImageBitmap(LangIcons.icon(c, lg.id) ?: LangIcons.flag(c, lg.id))
            }, Ui.lp(Ui.dp(c, 32), Ui.dp(c, 32)).apply { rightMargin = Ui.dp(c, 12) })
            row.addView(Ui.switchRow(c, lg.name, Prefs.enabledLangs.contains(lg.id)) { on ->
                val s = Prefs.enabledLangs.toMutableSet(); if (on) s.add(lg.id) else s.remove(lg.id)
                Prefs.enabledLangs = s; a.refreshPreview()
            }, Ui.lp(0, Ui.WRAP, 1f))
            l.addView(row)
        }
        root.addView(l)

        root.addView(Ui.title(c, "General"))
        val g = Ui.card(c)
        g.addView(Ui.switchRow(c, "Reminder notifications (3 & 10 days)", Prefs.reminders) { Prefs.reminders = it; Reminders.schedule(c) })
        g.addView(Ui.button(c, "Keyboard setup wizard") { c.startActivity(Intent(c, SetupActivity::class.java)) }.apply {
            layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8) }
        })
        g.addView(Ui.button(c, "Share app") {
            c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Try Neon Board – a neon LED keyboard!"), "Share"))
        }.apply { layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8) } })
        g.addView(Ui.button(c, "Privacy policy") {
            android.app.AlertDialog.Builder(c).setTitle("Privacy")
                .setMessage("Neon Board stores all settings, clipboard history and stickers only on your device. It does not collect or upload what you type, and has no network access.")
                .setPositiveButton("OK", null).show()
        }.apply { layoutParams = Ui.lp(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(c, 8) } })
        root.addView(g)
    }
}
