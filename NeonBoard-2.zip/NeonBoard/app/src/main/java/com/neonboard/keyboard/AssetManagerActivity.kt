package com.neonboard.keyboard

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

/** Manage every user asset in-app: import, rename, delete. No rebuild needed. */
class AssetManagerActivity : AppCompatActivity() {

    private val kinds = AssetStore.Kind.values()
    private var current = AssetStore.Kind.FONT
    private lateinit var body: LinearLayout
    private lateinit var tabRow: LinearLayout
    private val io = Executors.newSingleThreadExecutor()
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    // one picker per kind; each accepts all relevant MIME types so any format works
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isEmpty()) return@registerForActivityResult
        io.execute {
            var ok = 0
            for (u in uris) {
                val name = displayName(u)
                val extra = if (current == AssetStore.Kind.KAOMOJI) "" else ""
                if (AssetStore.add(this, current, u, name, extra) != null) ok++
            }
            main.post {
                toast("Added $ok of ${uris.size}")
                refresh()
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        AssetStore.init(this)
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 12))
        }
        root.addView(Ui.text(c, "Asset manager", 20f, Ui.ACCENT, true))
        root.addView(Ui.text(c, "Import, rename or delete your fonts, emoji art, stickers and kaomoji. Changes apply instantly.", 12f, Ui.MUTED).apply {
            setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 8))
        })
        tabRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val sv = android.widget.HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; addView(tabRow) }
        root.addView(sv)
        body = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(c).apply { addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun displayName(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { cur ->
            val i = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && cur.moveToFirst()) return cur.getString(i) ?: "file"
        }
        return u.lastPathSegment ?: "file"
    }

    private fun mimesFor(k: AssetStore.Kind): Array<String> = when (k) {
        AssetStore.Kind.FONT -> arrayOf("font/ttf", "font/otf", "font/*", "application/x-font-ttf", "application/octet-stream")
        AssetStore.Kind.EMOJI -> arrayOf("application/json", "text/*", "application/octet-stream")
        AssetStore.Kind.STICKER -> arrayOf("image/*")
        AssetStore.Kind.KAOMOJI -> arrayOf("application/json", "text/*")
    }

    private fun refresh() {
        tabRow.removeAllViews()
        for (k in kinds) {
            tabRow.addView(Ui.chip(this, k.label, k == current) { current = k; refresh() }.apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { rightMargin = Ui.dp(this@AssetManagerActivity, 8) }
            })
        }
        body.removeAllViews()
        body.addView(Ui.button(this, "＋ Import ${current.label.lowercase()}") {
            picker.launch(mimesFor(current))
        }.apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@AssetManagerActivity, 10) } })

        if (current == AssetStore.Kind.KAOMOJI) addKaomojiBox()
        if (current == AssetStore.Kind.EMOJI) body.addView(Ui.text(this,
            "Emoji files are JSON in the same format as the built-in pack: [{\"tag\":\"name\",\"list\":[{\"word\":\"😀\"}]}].", 12f, Ui.MUTED))
        if (current == AssetStore.Kind.FONT) body.addView(Ui.text(this,
            "Supports .ttf and .otf. Tap a font to preview it.", 12f, Ui.MUTED))
        if (current == AssetStore.Kind.STICKER) body.addView(Ui.text(this,
            "Images (PNG, JPG, WebP) and animated GIFs. Tap to preview, long-press to delete.", 12f, Ui.MUTED))

        val items = AssetStore.list(current)
        if (items.isEmpty()) {
            body.addView(Ui.text(this, "Nothing imported yet.", 14f, Ui.TEXT).apply { setPadding(0, Ui.dp(this@AssetManagerActivity, 18), 0, 0) })
            return
        }
        for (it in items) body.addView(row(it))
    }

    private fun addKaomojiBox() {
        val c = this
        val card = Ui.card(c)
        val input = EditText(c).apply {
            hint = "Type or paste a kaomoji, e.g. (๑•̀ㅂ•́)و✧"
            setHintTextColor(Ui.MUTED); setTextColor(Ui.TEXT); textSize = 15f
            background = Ui.bg(0x22FFFFFF, 10f, ctx = c); setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8))
        }
        card.addView(input)
        card.addView(Ui.button(c, "Save to “My kaomoji”") {
            val t = input.text.toString()
            if (t.isBlank()) return@button
            AssetStore.addKaomoji(c, t); input.setText(""); toast("Saved"); refresh()
        }.apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 8) } })
        body.addView(card)
    }

    private fun row(it: AssetStore.Item): View {
        val c = this
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8))
            background = Ui.bg(Ui.CARD, 12f, ctx = c)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = Ui.dp(c, 6) }
        }
        val preview: View = when (it.kind) {
            AssetStore.Kind.STICKER -> ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                StickerStore.thumb(AssetStore.fileOf(it), Ui.dp(c, 56))?.let { b -> setImageBitmap(b) }
            }
            AssetStore.Kind.FONT -> TextView(c).apply {
                text = "Aa"; textSize = 22f; setTextColor(Ui.TEXT)
                AssetStore.typeface(c, it)?.let { tf -> typeface = tf }
            }
            AssetStore.Kind.EMOJI -> TextView(c).apply { text = "😀"; textSize = 22f; gravity = Gravity.CENTER }
            AssetStore.Kind.KAOMOJI -> TextView(c).apply { text = "ツ"; textSize = 20f; setTextColor(Ui.TEXT); gravity = Gravity.CENTER }
        }
        card.addView(preview, LinearLayout.LayoutParams(Ui.dp(c, 56), Ui.dp(c, 56)))

        val info = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(c, 10), 0, 0, 0) }
        info.addView(Ui.text(c, it.name, 14f, Ui.TEXT, true))
        info.addView(Ui.text(c, it.file, 11f, Ui.MUTED))
        card.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        card.addView(Ui.button(c, "✎") { renameDialog(it) }.apply { setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4)) })
        card.addView(Ui.button(c, "🗑") { confirmDelete(it) }.apply { setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4)) })
        return card
    }

    private fun renameDialog(it: AssetStore.Item) {
        val input = EditText(this).apply { setText(it.name); setSingleLine() }
        AlertDialog.Builder(this).setTitle("Rename").setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) { AssetStore.rename(it, n); refresh() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun confirmDelete(it: AssetStore.Item) {
        AlertDialog.Builder(this).setTitle("Delete “${it.name}”?")
            .setMessage("This removes it from the app. It can't be undone.")
            .setPositiveButton("Delete") { _, _ -> AssetStore.delete(it); refresh() }
            .setNegativeButton("Cancel", null).show()
    }
}
