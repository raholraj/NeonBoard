package com.neonboard.keyboard

import android.content.Context
import android.graphics.Typeface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * On-device asset library. Everything the user imports (fonts, emoji packs, stickers/GIFs,
 * kaomoji packs) lives in filesDir/user_assets and is listed in index.json.
 * Changing assets never needs an APK rebuild.
 */
object AssetStore {
    private lateinit var root: File
    private lateinit var index: File
    private val lock = Any()

    /** Kinds of asset the user can manage. */
    enum class Kind(val folder: String, val label: String) {
        FONT("fonts", "Fonts"),
        EMOJI("emoji", "Emoji art"),
        STICKER("stickers", "Stickers & GIFs"),
        KAOMOJI("kaomoji", "Kaomoji")
    }

    fun init(ctx: Context) {
        synchronized(lock) {
            if (::root.isInitialized) return
            root = File(ctx.applicationContext.filesDir, "user_assets").apply { mkdirs() }
            Kind.values().forEach { File(root, it.folder).mkdirs() }
            index = File(root, "index.json")
        }
    }

    // ---- index ----
    data class Item(val id: String, val kind: Kind, val name: String, val file: String, val added: Long, val extra: String = "")

    private fun readIndex(): MutableList<Item> = synchronized(lock) {
        val out = ArrayList<Item>()
        try {
            if (index.exists()) {
                val a = JSONArray(index.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Item(o.getString("id"), Kind.valueOf(o.getString("kind")), o.getString("name"),
                        o.getString("file"), o.optLong("added"), o.optString("extra")))
                }
            }
        } catch (_: Exception) {}
        out
    }

    private fun writeIndex(list: List<Item>) = synchronized(lock) {
        val a = JSONArray()
        for (it in list) a.put(JSONObject().put("id", it.id).put("kind", it.kind.name).put("name", it.name)
            .put("file", it.file).put("added", it.added).put("extra", it.extra))
        val tmp = File(root, "index.json.tmp")
        tmp.writeText(a.toString())
        tmp.renameTo(index)
    }

    fun list(kind: Kind): List<Item> = readIndex().filter { it.kind == kind }.sortedByDescending { it.added }

    fun fileOf(item: Item): File = File(File(root, item.kind.folder), item.file)

    /** Copy a picked document into the library. Returns the new item or null. */
    fun add(ctx: Context, kind: Kind, uri: android.net.Uri, displayName: String, extra: String = ""): Item? {
        init(ctx)
        val ext = displayName.substringAfterLast('.', "").lowercase().take(5)
        val id = "${System.currentTimeMillis()}_${(0..99999).random()}"
        val file = "$id.${ext.ifEmpty { "bin" }}"
        val dest = File(File(root, kind.folder), file)
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                ?: return null
            if (dest.length() == 0L) { dest.delete(); return null }
            val item = Item(id, kind, displayName.substringBeforeLast('.').ifEmpty { displayName }, file, System.currentTimeMillis(), extra)
            synchronized(lock) { writeIndex(readIndex() + item) }
            Changes.bump()
            item
        } catch (e: Exception) { dest.delete(); null }
    }

    fun rename(item: Item, newName: String) {
        synchronized(lock) {
            writeIndex(readIndex().map { if (it.id == item.id) it.copy(name = newName) else it })
        }
        Changes.bump()
    }

    fun delete(item: Item) {
        synchronized(lock) {
            fileOf(item).delete()
            writeIndex(readIndex().filter { it.id != item.id })
        }
        Changes.bump()
    }

    // ---- fonts ----
    private val fontCache = HashMap<String, Typeface?>()
    fun typeface(ctx: Context, item: Item): Typeface? = synchronized(fontCache) {
        fontCache.getOrPut(item.id) {
            try { Typeface.createFromFile(fileOf(item)) } catch (_: Exception) { null }
        }
    }

    // ---- emoji packs: JSON array of {tag, list:[{word}]} ----
    data class EmojiPack(val tag: String, val items: List<String>)
    fun emojiPacks(ctx: Context): List<EmojiPack> {
        init(ctx)
        val out = ArrayList<EmojiPack>()
        for (it in list(Kind.EMOJI)) {
            try {
                val a = JSONArray(fileOf(it).readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val l = o.getJSONArray("list")
                    val items = (0 until l.length()).map { j -> l.getJSONObject(j).getString("word") }
                    out.add(EmojiPack(o.getString("tag"), items))
                }
            } catch (_: Exception) {}
        }
        return out
    }

    // ---- kaomoji packs: each file is a JSON array of strings, or {name, emoji:[...]} ----
    fun kaomojiPacks(ctx: Context): List<Pair<String, List<String>>> {
        init(ctx)
        val out = ArrayList<Pair<String, List<String>>>()
        for (it in list(Kind.KAOMOJI)) {
            try {
                val t = fileOf(it).readText().trim()
                if (t.startsWith("[")) {
                    val a = JSONArray(t)
                    if (a.length() > 0 && a.get(0) is JSONObject) {
                        for (i in 0 until a.length()) {
                            val o = a.getJSONObject(i)
                            val e = o.getJSONArray("emoji")
                            out.add(o.optString("name", it.name) to (0 until e.length()).map { j -> e.getString(j) })
                        }
                    } else {
                        out.add(it.name to (0 until a.length()).map { j -> a.getString(j) })
                    }
                }
            } catch (_: Exception) {}
        }
        return out
    }

    /** Text-only kaomoji you typed in the app: stored as a single pack named "My kaomoji". */
    fun addKaomoji(ctx: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val existing = list(Kind.KAOMOJI).firstOrNull { it.name == "My kaomoji" }
        val arr = if (existing != null) JSONArray(fileOf(existing).readText()) else JSONArray()
        arr.put(t)
        if (existing != null) {
            fileOf(existing).writeText(arr.toString())
            Changes.bump()
        } else {
            val tmp = File(File(root, Kind.KAOMOJI.folder), "my_kaomoji_${System.currentTimeMillis()}.json")
            tmp.writeText(arr.toString())
            synchronized(lock) {
                writeIndex(readIndex() + Item(tmp.nameWithoutExtension, Kind.KAOMOJI, "My kaomoji", tmp.name, System.currentTimeMillis()))
            }
            Changes.bump()
        }
    }

    /** Tiny change counter so open panels/pages know to refresh. */
    object Changes {
        @Volatile var version = 0
        fun bump() { version++ }
    }
}
