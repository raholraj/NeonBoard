package com.neonboard.keyboard

import android.content.Context
import android.graphics.Typeface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * In-app asset store. Bundled assets ship in the APK (read-only). Anything the user imports lives in
 * filesDir/user/<kind>/ and is merged at runtime — so no rebuild is needed to add or remove content.
 *
 * kinds: fonts, emoji (json groups), stickers (images), kaomoji (json lines), sounds (audio files)
 */
object Assets {
    private val tokens = HashMap<String, Long>()

    fun root(ctx: Context): File = File(ctx.filesDir, "user").apply { mkdirs() }
    fun dir(ctx: Context, kind: String): File = File(root(ctx), kind).apply { mkdirs() }

    /** Lightweight change counter: bumped on any import/delete so open panels can refresh. */
    @Synchronized fun bump(kind: String) { tokens[kind] = (tokens[kind] ?: 0L) + 1 }
    @Synchronized fun token(kind: String): Long = tokens[kind] ?: 0L

    // ---------------- generic copy ----------------
    fun importUri(ctx: Context, uri: android.net.Uri, kind: String, name: String): File? = try {
        val f = File(dir(ctx, kind), name)
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (f.exists() && f.length() > 0) { bump(kind); f } else { f.delete(); null }
    } catch (e: Exception) { null }

    fun displayName(ctx: Context, uri: android.net.Uri): String {
        ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: ""
        }
        return uri.lastPathSegment ?: "file"
    }

    fun list(ctx: Context, kind: String, exts: Set<String>): List<File> =
        (dir(ctx, kind).listFiles() ?: emptyArray()).filter { it.isFile && it.extension.lowercase() in exts }
            .sortedBy { it.name.lowercase() }

    fun delete(ctx: Context, f: File) { if (f.delete()) bump(f.parentFile?.name ?: "") }

    // ---------------- fonts ----------------
    private val userFontCache = HashMap<String, Typeface>()
    fun userFonts(ctx: Context): List<File> = list(ctx, "fonts", setOf("ttf", "otf"))
    fun userFontTypeface(ctx: Context, f: File): Typeface? = synchronized(userFontCache) {
        userFontCache.getOrPut(f.path) { try { Typeface.createFromFile(f) } catch (e: Exception) { return null } }
    }
    fun clearFontCache() = synchronized(userFontCache) { userFontCache.clear() }

    // ---------------- emoji groups ----------------
    /** User emoji group: a file named "<tag>.json" containing a JSON array of strings, or a text file, one per line. */
    fun userEmojiGroups(ctx: Context): List<Pair<String, List<String>>> =
        list(ctx, "emoji", setOf("json", "txt")).mapNotNull { f ->
            try {
                val raw = f.readText(Charsets.UTF_8).trim()
                val items = if (f.extension == "json") {
                    val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) }
                } else raw.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (items.isEmpty()) null else f.nameWithoutExtension.replaceFirstChar { it.uppercase() } to items
            } catch (e: Exception) { null }
        }

    // ---------------- kaomoji ----------------
    fun userKaomoji(ctx: Context): List<Pair<String, List<String>>> =
        list(ctx, "kaomoji", setOf("txt")).mapNotNull { f ->
            val items = f.readLines(Charsets.UTF_8).map { it.trim() }.filter { it.isNotEmpty() }
            if (items.isEmpty()) null else f.nameWithoutExtension.replaceFirstChar { it.uppercase() } to items
        }

    // ---------------- reset ----------------
    fun resetAll(ctx: Context) {
        root(ctx).deleteRecursively()
        root(ctx).mkdirs()
        clearFontCache()
        listOf("fonts", "emoji", "stickers", "kaomoji", "sounds").forEach { bump(it) }
    }

    /** Clipboard helpers live in Prefs; this keeps every user-editable list in one place. */
    fun summary(ctx: Context): String =
        "Fonts ${userFonts(ctx).size} · Emoji groups ${userEmojiGroups(ctx).size} · " +
        "Stickers ${list(ctx, "stickers", setOf("png", "jpg", "jpeg", "gif", "webp")).size} · " +
        "Kaomoji groups ${userKaomoji(ctx).size} · Sounds ${list(ctx, "sounds", setOf("mp3", "wav", "ogg", "m4a")).size}"
}
